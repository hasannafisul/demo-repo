import { useMediaQuery } from 'use-mediaquery'
import React, { useState } from 'react'
import { Num, Question } from './Number'

const MobonQues = () => {
    const matches4 = useMediaQuery(`(min-width:920px)`)
    const matches5 = useMediaQuery(`(min-width:768px)`)
    const matches6 = useMediaQuery(`(min-width:576px)`)
    const [num, setnum] = useState(0);
    let Skiparr = [];
    return (
        <div className='container-fluid' style={{ backgroundColor: '#f5f5f5', padding: '1rem 10px' }}>

            <div className="col-sm-6">
                <div className='mx-2 mt-5' style={{ fontSize: matches5 ? '1.5rem' : '.9rem', display: 'flex', justifyContent: matches6 ? 'center' : 'start', alignItems: 'center' }}>

                    <p className=''>Attempted:0/20</p>

                    <p className='mx-4'>Skip:0</p>
                    <p className={matches4 ? '' : 'mx-2'}>Time: 30:00</p>

                </div>
                <div className='my-2' style={{ fontSize: '2rem' }}>
                    {Question.map((item, index) => {
                        return (<button key={index} style={{ backgroundColor: Skiparr.includes(index) ? '#3bc43b' : 'none', margin: '5px', padding: '0px 20px', color: 'green', backgroundColor: '#dododo', borderRadius: '8px', border: 'none' }} onClick={() => setnum(index)}> {index + 1}</button>);
                    })}
                </div>
            </div>

            <div className='mt-5' style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <input className="form-check-input mt-0 mx-1" type="checkbox" value="" /> color1
                <input className="form-check-input mt-0 mx-1" type="checkbox" value="" /> color1
                <input className="form-check-input mt-0 mx-1" type="checkbox" value="" /> color1
            </div>

            <div className='mt-5' style={{ textAlign: 'center' }}>

                <button type="button" className="btn " style={{ width: '200px', backgroundColor: '#000080', color: '#fff', borderRadius: '15px' }}>Start</button>

            </div>

        </div>
    )
}

export default MobonQues