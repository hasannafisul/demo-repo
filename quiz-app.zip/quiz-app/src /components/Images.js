import axios from 'axios'
import React,{useState} from 'react'

const Images = () => {

const [image, setimage] = useState('')
const [filed, setfiled] = useState("")
const handlechange=(e)=>{
console.log(e.target.files)
setfiled(e.target.files)
setimage(e.target.files[0])

}



const handleApi=()=>{

    const url = 'http://localhost:2002/api/image'
    const formData = new FormData()
    formData.append('image',image)
    axios.post(url, formData).then((res)=>{
        setimage('')
console.log(res.data);


    }).catch((err)=>{
        console.log(err);
    })
 

}

  return (
    <div className='mx-5 mt-5'>
       <img src={image === '' ? '': URL.createObjectURL(image)} style={{height:'5rem' , width:'5rem'}} alt="" />
        IMAGE UPLOAD

            <input type="file"  className="form-control"   id="file" aria-label="file" onChange={handlechange} />



<button type="submit" className="btn btn-primary mb-5 mt-3"
              onClick={handleApi}>submit</button>


    </div>
  )
}

export default Images