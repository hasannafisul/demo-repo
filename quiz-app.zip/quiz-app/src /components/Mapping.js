import React from 'react'
import { Num } from "./Number";
const Mapping = () => {
    // let Number =[];
// let count =0;

// return(

// <button onClick={()=>{
//     Number.push(count);
//     count++;
//     console.log(Number);


// }}>click me</button>
// )
    return (
        <>
            <div className="col-sm-12" style={{padding:'0px 20px'}}>
                <div className="row">
                    <div className="col-sm-1"></div>

                    <div className="col-sm-2 mt-5" style={{ display: 'flex-column', justifyContent: 'space-around', border: '2px solid blue' }}>
                        {Num.map((item, index) => {
                            return <button className="mx-1 my-1"> {item}</button>;
                        })}

                    </div>



                    <div className="col-sm-2"></div>
                    <div className="col-sm-6 mt-5">
                        <div className="row">


                   <div className="col-sm-12">

                            <p>Q1. Which is the Capital of India</p>
                            </div>
                    <div className="col-sm-12">
<div className="row">
<div className="col-sm-3">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                <label class="form-check-label" for="inlineRadio1">  Mumbai</label>
                            </div>
                            </div>
<div className="col-sm-3">

                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                <label class="form-check-label" for="inlineRadio1"> Gujrat</label>
                            </div>
                            </div>
                            </div>
                            </div>


                        <div className="col-sm-12">
                            <div className="row">
                            <div className="col-sm-3">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                <label class="form-check-label" for="inlineRadio1"> Lucknow</label>
                            </div>
                            </div>
                        
                            <div className="col-sm-3">

                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                <label class="form-check-label" for="inlineRadio1">  New Delhi</label>
                            </div>
                            </div>
                            </div>
                            </div>
                            
                       
                        <div className='col-sm-10 mt-3'>
                            <div className="row">
                                <div className="col-sm-2">
                                    <button className='btn btn-primary' style={{padding:'1px 8px',fontSize:'16px'}}>Skip</button>
                                </div>
                                <div className="col-sm-2">
                                    <button className='btn btn-success' style={{padding:'1px 8px',fontSize:'16px'}}>Next</button>
                                </div>
                                </div>

                            </div>

                    <div>

                </div>
            </div>
            </div>
            </div>

</div>


        </>
    )
}

export default Mapping
























{/* <div className="col-sm-12">
<div className="row">
    <div className="col-sm-1"></div>
    
    <div className="col-sm-2 mt-5" style={{ display: 'flex-column', justifyContent: 'space-around', border: '2px solid blue' }}>
        {Num.map((item, index) => {
            return <button className="mx-1 my-1"> {item}</button>;
        })}

    </div>



    <div className="col-sm-1"></div>
    <div className={matches1 ? "col-sm-7 mt-5" : "col-sm-12 mt-5 "} >
        <div className={matches1 ? 'col' : 'col mx-5'}>

            <p>Q1. Which is the Capital of India</p>
            <div className="col-sm-6">
                <div className="col-sm-12">
                    <div className="row">

                        <div className="col-sm-6">

                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                <label class="form-check-label" for="inlineRadio1">A.  Mumbai</label>
                            </div>
                        </div>

                        <div className="col-sm-6">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                <label class="form-check-label" for="inlineRadio1">B.  Gujrat</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-sm-6">
                <div className="row">
                    <div className="col-sm-6" >
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                            <label class="form-check-label" for="inlineRadio1">C. Lucknow</label>
                        </div>
                    </div>
                    <div className="col-sm-6">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                            <label class="form-check-label" for="inlineRadio1">D.  New Delhi</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className={matches1 ? 'col-sm-7 mt-5' : "col-sm-12 mx-5 mt-2"}>
            <div className="row">
                <div className="col-sm-2">
                    <button className='btn btn-primary'>Skip</button>
                </div>
                <div className="col-sm-2">
                    <button className='btn btn-success' onClick={() => { }}>Next</button>
                </div>

            </div>
        </div>

    </div>

</div>
</div> */}