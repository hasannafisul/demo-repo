import { useMediaQuery } from 'use-mediaquery'
import axios from 'axios';
import React from 'react'
import { useContext } from 'react';
import { useEffect } from 'react';
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom';
import Ncontext from '../ContextC';
import exam from '../Images/examlogo.png'
import infranix from "../Images/infranix.png";

const DesktopInstruct = () => {
  let navigate = useNavigate();
  const matches1 = useMediaQuery(`(max-width:666px)`)
  const matches2 = useMediaQuery(`(min-width:576px)`)
  const matches3 = useMediaQuery(`(min-width:1040px)`)
  const matches4 = useMediaQuery(`(min-width:800px)`)
  const matches5 = useMediaQuery(`(min-width:1310px)`)

  const context = useContext(Ncontext);
  const { sessionId, setsessionId } = context;

  const [bool, setbool] = useState(false)
  const [email, setemail] = useState('')
  const [coupon, setcoupon] = useState('')


  const allotExam = () => {
    axios.post("http://192.168.29.136:8080/api/allot_exam", { user_id: email, coupon_code: coupon }).then((res) => {
      setsessionId(res.data.session_id);
      // setemail('')
      // setcoupon('')
      navigate('/home')
      // console.log();
      console.log(res.data.setsessionId);
    }).catch((err) => {
      console.log(err);
    })
  }

  const bColor = { backgroundColor: '#6c6c6c' }
  const pColor = { color: '#fff' }



  return (
    <div style={bColor}>

      {/* ..............first row ................................. */}

      <header>

        <div className='col-sm-12' style={{ backgroundColor: '#6c6c6c', fontFamily: 'serif', padding: '10px 50px 3px 50px', borderBottom: '2px solid yellow' }}>
          <div className="row">
            <div className="col-sm-2"></div>
            <div className={matches1 ? "col-sm-12" : "col-sm-2"} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
              <h4 style={{ color: '#fff' }}><span> Online Exam </span> <span style={{ color: 'red' }}> Portal</span> </h4>
            </div>

            <div className={matches1 ? "col-sm-12" : "col-sm-8"} style={{ display: 'flex', justifyContent: 'end', alignItems: 'center' }}>
              <div className="col-sm-12" style={{ padding: '10px 50px 3px 50px' }}>
                <div className="row">

                  <div className='col-sm-5' style={{ display: 'flex', justifyContent: matches2 ? 'end' : 'center', alignItems: 'center', marginLeft: matches2 ? '' : '10px' }}>
                    <h5 style={{ color: '#fff' }}><span style={{ backgroundColor: '#990000', padding: '5px' }}>12:00:00</span><span style={{ backgroundColor: '#606060', padding: '5px' }}>Timer</span> </h5>
                  </div>

                  <div className='col-sm-3' style={{ display: 'flex', justifyContent: matches2 ? 'start' : 'center', alignItems: 'center' }}>

                    <ul className='mt-2' >

                      <li className="dropdown" style={{ listStyle: 'none' }}>
                        <button className=" dropdown-toggle" role="button" data-bs-toggle="dropdown"
                          style={{ backgroundColor: '#990000', color: '#fff', textDecoration: 'none', width: '10rem', display: 'flex', justifyContent: 'start', alignItems: 'center' }}> <img src={exam} /> <span className='mx-2'>Nafis</span>

                        </button>

                      </li>

                    </ul>

                  </div>

                </div>
              </div>
            </div>
            <div >
            </div>

            <div>


            </div>

          </div>
        </div>

      </header>




      {/* .............   .........second row...............................  ............*/}



      <div>

        <div className="col-sm-12" style={{ padding: '8px 49px 0px 50px' }}>
          <div className="row" >

            <div className="col-sm-2"></div>
            <div className="col-sm-7" style={{ backgroundColor: 'GrayText', marginLeft: '1rem', border: '4px solid black' }}>

              <div className={matches3 ? "col-sm-12" : "col-sm-10"} style={{ padding: '15px 50px 10px 50px' }}>
                <div className="row">
                  <div className={matches4 ? "col-sm-4" : "col-sm-9"} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                    <h6 style={{ color: '#fff' }}><span> Max Marks: 100 </span> </h6>
                  </div>

                  <div className={matches4 ? "col-sm-4" : "col-sm-9"} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>

                    <h6 style={{ color: '#fff' }}> Exam Name:MBA</h6>
                  </div>

                  <div className={matches4 ? "col-sm-4" : "col-sm-9"} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }} >
                    <h6 style={{ color: '#fff' }}>Max: 1h-15min  </h6>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
      {/* .......................Thirsd row.............Para................... */}



      <div>

        <div className="col-sm-12" style={{ alignItems: 'center', padding: "0px 34px 3px 66px", fontSize: '.8rem' }}>
          <div className="row">

            <div className="col-sm-2"></div>
            <div className="col-sm-7 mb-3" style={{ border: '4px solid black', borderTop: 'none', backgroundColor: '#fff' }}>
              <div className="row">

                <div className="col-sm-12 my-4" >
                  <div className="row">
                    {/* <div className="col-sm-1"></div> */}
                    <div className="col-sm-6" style={{ padding: '0px 2rem 0px 2rem' }}>
                      <div>
                        <h5>You would be assessed on the following topics</h5>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> Business Process & IT, Managing sales Marketing, finance & accounting. </p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> Designing Business Tier and developing and application Using Status. </p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> Developing and Dynamic Forms and Sharing application Resource.</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> Developing JSP Pages and Custom Tags.</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> Dveloping View and Controller Components</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> Integrating Web Applications with Databases</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> Introduction to Web Application Technologies</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> JavaBeans, Creating Custom Tags, and Securing Web Applications</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> Using Sesion Management and Filters in Web Applications</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> Using Struts Action Forms and Building Reusable Web Components</p>
                      </div>
                    </div>

                    <div className="col-sm-6" style={{ padding: '0px 2rem 0px 2rem' }}>
                      <div>
                        <h5>Test Instructions</h5>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'>  To Start the test, click on the "Start Test" button.</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'>  The Objective Test includes Multiple choice questions and detailed answer has to be written for Subjective Test,</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'>  Questions may include additional information such as sample code or graphics.</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> All questions may not carry same marks.</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> Select the correct answer by clicking on the appropriate option (Incase of Multiple Choice Questions)</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> For Subjective Questions, type in the answer in the text area provided.</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> You must select or write an answer for every question (Depending upon the Mode of Question ).</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'> To finish the test, press "End Exam" button anytime.</p>
                      </div>
                      <div style={{ display: 'flex' }}>
                        <p><i className='fas fa-arrow-right' style={{ color: 'green' }}></i></p>
                        <p className='mx-2'>  You may view the correct feedback at the end of your test.</p>
                      </div>

                    </div>


                    {/* </div>  */}
                  </div>
                </div>

                {/*......... ..........................checkbox................................... */}

                <div className="col-sm-12" style={{ padding: '0px 0rem 0px 1.8rem' ,fontSize:'1rem'}}>
                  <div className="col-sm-1"></div>
                  <div className="row">
                    {/* <div className="col-sm-1"></div> */}
                    <div className={matches5?"col-sm-4":'col-sm-12'}>
                      <div className="form-check">
                        <input className="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked={bool} onClick={() => {
                          if (bool == false) {
                            setbool(true)
                          }
                          else {
                            setbool(false)
                          }
                        }} />
                        <label className="form-check-label" for="flexCheckChecked">
                          I accept all the conditions
                        </label>
                      </div>
                    </div>
                  </div>
                </div>


              </div>
            </div>

          </div>

        </div>
      </div>








      {/* ................................input field ............................. */}




      <div className="col-sm-12" style={{ padding: '0px 49px 0px 5.5rem', fontSize: '.8rem', display: bool ? 'block' : 'none' }}>
        <div className="row">
          <div className="col-sm-2"></div>
          <div className="col-sm-4" style={{ maxHeight: '100%', maxWidth: '100%' }}>

            <form>
              <div className="mb-3" style={pColor}>
                <label for="exampleInputEmail1" className="form-label">Email address</label>
                <input type="email" className="form-control" value={email} onChange={(e) => {
                  setemail(e.target.value)
                }} style={{ height: '2rem' }} id="exampleInputEmail1" aria-describedby="emailHelp" />
              </div>
              <div className="mb-3" style={pColor}>
                <label for="exampleInputPassword1" className="form-label">Coupon Code</label>
                <input type="text" className="form-control" value={coupon} onChange={(e) => {
                  setcoupon(e.target.value)
                }} style={{ height: '2rem' }} id="exampleInputPassword1" />

              </div>

            </form>

          </div>

        </div>
      </div>








      {/* ..............................fourth row............................... */}

      <section>

        <div className="col-sm-12 mb-1" style={{ textAlign: 'center' }} >
          <button className='btn ' onClick={() => {
            // alert('click')
            allotExam()
          }} style={{ color: '#fff', backgroundColor: '#008000', fontSize: '.8rem' }} disabled={!bool}> Start Exam</button>



        </div>
      </section>




      <footer>

        <div className='col-sm-12' style={{ backgroundColor: '#6c6c6c', fontFamily: 'serif', padding: '10px 50px 3px 50px', borderTop: '4px solid #858383' }}>
          <div className="row">
            <div className="col-sm-2"></div>
            <div className={matches1 ? "col-sm-12" : "col-sm-2"} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
              <h4 style={{ color: '#fff' }}><span> Online Exam </span> <span style={{ color: 'red' }}> Portal</span> </h4>
            </div>

            <div className={matches1 ? "col-sm-12" : "col-sm-8"} style={{ display: 'flex', justifyContent: 'end', alignItems: 'center' }}>
              <div className="col-sm-12" style={{ padding: '10px 50px 3px 50px' }}>
                <div className="row">

                  <div className='col-sm-5' style={{ display: 'flex', justifyContent: matches2 ? 'end' : 'center', alignItems: 'center', marginLeft: matches2 ? '' : '10px' }}>
                    <h5 style={{ color: '#fff' }}><span style={{ padding: '5px', fontSize: '.8rem' }}>Powered By: </span> </h5>
                  </div>

                  <div className='col-sm-3' style={{ display: 'flex', justifyContent: matches2 ? 'start' : 'center', alignItems: 'center' }}>
                    <span >  <img src={infranix} style={{ width: '12rem' }} /> </span>

                  </div>

                </div>
              </div>
            </div>
            <div >
            </div>

            <div>


            </div>

          </div>
        </div>

      </footer>









    </div>

  )
}

export default DesktopInstruct