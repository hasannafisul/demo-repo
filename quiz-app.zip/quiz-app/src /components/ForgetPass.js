import { padding } from '@mui/system';
import axios from 'axios';
import React, { useState } from 'react'
const ForgetPass = () => {

  const [email, setemail] = useState('');
  const [newpassword, setnewpassword] = useState('');


  const checkData = (e) => {
    e.preventDefault();
    axios.post('http://localhost:1998/resetpass', { email: email, newpassword: newpassword }).then((res) => {
      console.warn(res.data);
      if (res.data.status === 1) {
        window.alert("Password Changed Successfully")

        // window.location.href = "/dash"
        setemail('');
        setnewpassword('')




      } else {
        window.alert("please fill right email")
      }







    }).catch((err) => {
      console.log(err);
    })


  }

  return (
    <div className='container' style={{ backgroundColor: '#F2FBE9	', padding:'5rem 5rem' }}>
      <div className="row">
        <div className="col-sm-4"></div>
        <div className="col-sm-4" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <form>
            <div className="mb-2 mt-4">
              <h1 style={{marginBottom:'-2rem'}}> Reset Pasword </h1>
              <label for="exampleInputEmail1" className="form-label  mt-5">Email </label>
              <input type="email" className="form-control" value={email} id="exampleInputEmail1" aria-describedby="emailHelp" placeholder='Enter Email' onChange={(e) => {
                setemail(e.target.value);
              }} />
              <div id="emailHelp" className="form-text">Please fill right email </div>
            </div>


        <div className="mb-3">
          <label for="exampleInputPassword1" className="form-label">New Password</label>
          <input type="password" value={newpassword} className="form-control" placeholder='enter password' id="exampleInputPassword1" onChange={(e) => {
            setnewpassword(e.target.value);
          }} />
        </div>


              <button type="Reset" className="btn btn-primary mb-4" onClick={(e) => {
                checkData(e)
              }} >Reset</button>




          </form>

        </div>
      </div>


    </div>




  )
}

export default ForgetPass