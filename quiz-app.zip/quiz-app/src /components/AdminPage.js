
import axios from 'axios';
import React, { useState } from 'react'

const AdminPage = () => {

const [bool, setbool] = useState(false);
const [list,setlist]=useState([]);

const showData=()=>{
    
axios.get('http://localhost:1998/showdesk').then((res)=>{
    console.log(res.data.adminData);
    setlist(res.data.adminData)
})
.catch((err)=>{
console.log(err);
})

}



  return (
    <div className='container-fluid'>
        
<h1 style={{textAlign:'center',color:'green',position:'relative',top:'4rem'}}> Admin Page</h1>
<div className="row">
<div className="col-sm-2 mt-5">
<div style={{border:'2px solid black',height:'100vh',maxWidth:'100%',backgroundColor:'#F3FCDA' }}>

<button className='btn btn-primary' onClick={()=>{


showData()
if(bool===false){
    setbool(true)
}
else{
setbool(false);
}
}}> click me </button>


</div>



</div>
<div className="col-sm-8">

<div className='table-responsive' style={{display:bool?'block':'none'}}>
<table className="table  table-hover table-striped  mt-5" style={{border:'2px solid black'}}>
  
  <thead>
    <tr>
    <th scope="col">Sno.</th>

      <th scope="col">id</th>
      <th scope="col">name</th>
      <th scope="col">phone</th>
      <th scope="col">email</th>
      <th scope="col">pasword</th>
      <th scope="col">confirmpassword</th>
    </tr>
  </thead>
  <tbody>
    {
        list.map((item,index)=>{
                return(  
            <tr>
                {index}
      <th>{item._id}</th>
      <td>{item.name}</td>
      <td>{item.phone}</td>
      <td>{item.email}</td>
      <td>{item.password}</td>
      <td>{item.confirmpassword}</td>
    </tr>
            )
        })
    }
    
   
  </tbody>
</table>
</div>


</div>


</div>






    </div>
  )
}

export default AdminPage




