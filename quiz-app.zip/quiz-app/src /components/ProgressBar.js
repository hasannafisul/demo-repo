// import React from 'react'
// import { useState } from 'react'

// const ProgressBar = ({bgcolor,progress,height}) => {
	
// 	const [bar, setbar] = useState({});


// setTimeout(() => {
//     const newStyle ={
//         opacity:1,
//          width:`${progress}%`
//      }
//      setbar(newStyle) 
    
// }, 1000);

		
// 	return (
//         <div className='progress' style={{height: height,width: '100%',backgroundColor: 'whitesmoke',borderRadius: 40,margin: 50}}>
// 	<div style={bar}>
// 	<div style={{height: '100%',width: `${progress}%`,backgroundColor: bgcolor,borderRadius:40,textAlign: 'right'}}>
// 	<div style={bar}>	<span style={{padding: 10,color: 'black',fontWeight: 900 }}>{`${progress}%`}</span></div>
// 	</div>

// 	</div>




//     </div>
// 	)
// }

// export default ProgressBar;










import React, { useState, useEffect } from 'react';

const ProgressBar = () => {
    const [count, setCount] = useState(0);
    useEffect(() => {
      // Update the document title using the browser API
      document.title = `You clicked ${count} times`;
      console.log(document.title);
    });
  return (
    <div>
        
{/* ................................... */}





    <div>
      <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>
        Click me
      </button>
    </div>


        {/* ................................... */}
    </div>
  )
}

export default ProgressBar