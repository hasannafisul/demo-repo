import { useMediaQuery } from 'use-mediaquery'
import React, { useState } from 'react'
import exam from '../Images/examlogo.png'
import { Num, Question } from './Number'
import infranix from "../Images/infranix.png";
import { useEffect } from 'react';
import axios from 'axios';
import Ncontext from '../ContextC';
import { useContext } from 'react';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {


  const context = useContext(Ncontext);
  const { sessionId, setsessionId } = context;
  const [value, setvalue] = useState('')
  let navigate = useNavigate();
  const [boolbutton, setboolbutton] = useState(true);
  const [bool, setbool] = useState(false);
  const [skipbool, setskipbool] = useState(false);
  const [numberq, setnumberq] = useState(1);
  // let id =sessionId;
  useEffect(() => {
    axios.get("http://192.168.29.136:8080/getSessionValue").then((res) => {
      if (res.data) {
        setsessionId(res.data)
        axios.post("http://192.168.29.136:8080/api/get_question_list", { session_id: res.data }).then((res) => {
          setq_list(res.data)
          setqnum(res.data[0].q_id)
          axios.post("http://192.168.29.136:8080/api/get_question", { q_id: res.data[0].q_id }).then((res) => {
            setquestion(res.data);
          }).catch((err) => {
            console.log(err);
          })
        }).catch((err) => {
          console.log(err);
        })
      }
      else {
        window.location.href = '/'
      }
    }).catch((err) => {
      console.log(err);
    })
  }, [])


  const finish_exam = () => {
    axios.get("http://192.168.29.136:8080/destroy").then((res) => {
      alert("Submitted Successfully");
      navigate('/');
    }).catch((err) => {
      console.log(err);
    })
  }



  const matches1 = useMediaQuery(`(max-width:666px)`)
  const matches2 = useMediaQuery(`(min-width:576px)`)
  const matches3 = useMediaQuery(`(min-width:1030px)`)
  const matches4 = useMediaQuery(`(min-width:800px)`)
  const matches5 = useMediaQuery(`(min-width:870px)`)


  // used for how question

  const matches6 = useMediaQuery(`(min-width:820px)`)
  const para = {
    fontSize: '.7rem',



  }
  const [num, setnum] = useState(0);
  const [count, setcount] = useState(0)
  let Skiparr = [];

  const body = {
    backgroundColor: "#6c6c6c"
  }

  const [bool1, setbool1] = useState(false);
  const [bool2, setbool2] = useState(false);
  const [bool3, setbool3] = useState(false);
  const [bool4, setbool4] = useState(false);


  const [q_list, setq_list] = useState([]);
  const [question, setquestion] = useState({});
  const [qnum, setqnum] = useState(0)
  const [a_id, seta_id] = useState(0)
  // const [prev_a_id, set_prev_a_id] = useState(0)

  let skip = -1;
  let not_attempted = 0;
  // document.body.requestFullscreen();
  document.addEventListener('contextmenu', event => event.preventDefault());
 
  useEffect(() => {
    axios.post("http://192.168.29.136:8080/api/get_question_list", { session_id: sessionId }).then((res) => {
      setq_list(res.data)
      setqnum(res.data[0].q_id)
      axios.post("http://192.168.29.136:8080/api/get_question", { q_id: res.data[0].q_id }).then((res) => {
        setquestion(res.data);
      }).catch((err) => {
        console.log(err);
      })
    }).catch((err) => {
      console.log(err);
    })
  }, [])

  const get_q_list = () => {
    axios.post("http://192.168.29.136:8080/api/get_question_list", { session_id: sessionId }).then((res) => {
      setq_list(res.data)
      // console.log(res.data);
    }).catch((err) => {
      console.log(err);
    })
  }


  const getquestion = (q_number, qnumprev, aid) => {
    setqnum(q_number);
    axios.post("http://192.168.29.136:8080/api/get_question", { q_id: q_number, save_a_id: aid, save_q_id: qnumprev }).then((res) => {
      setquestion(res.data);
      console.log(res.data.prev_a_id);
      seta_id(res.data.prev_a_id)
      setbool1(res.data.prev_a_id == res.data.options[0].a_id ? true : false);
      setbool2(res.data.prev_a_id == res.data.options[1].a_id ? true : false);
      setbool3(res.data.prev_a_id == res.data.options[2].a_id ? true : false);
      setbool4(res.data.prev_a_id == res.data.options[3].a_id ? true : false);
      setboolbutton(res.data.prev_a_id==0 || res.data.prev_a_id==-1  ? true :false);
      get_q_list();
    }).catch((err) => {
      console.log(err);
    })
  }

  const get_prev_ques = (q_number) => {
    setqnum(q_number)
    axios.post("http://192.168.29.136:8080/api/get_question", { q_id: q_number }).then((res) => {
      seta_id(res.data.prev_a_id)
      setquestion(res.data);
      setbool1(res.data.prev_a_id == res.data.options[0].a_id ? true : false);
      setbool2(res.data.prev_a_id == res.data.options[1].a_id ? true : false);
      setbool3(res.data.prev_a_id == res.data.options[2].a_id ? true : false);
      setbool4(res.data.prev_a_id == res.data.options[3].a_id ? true : false);
      // get_q_list();
      setboolbutton(res.data.prev_a_id==0 || res.data.prev_a_id==-1 ? true :false);
    }).catch((err) => {
      console.log(err);
    })
  }


  return (
    <div style={body}>
      <header>
        <div className='col-sm-12' style={{ backgroundColor: '#6c6c6c', fontFamily: 'sans-serif', padding: '10px 25px 3px 30px', borderBottom: '2px solid yellow' }}>
          <div className="row">
            <div className="col-sm-2" ></div>
            <div className={matches1 ? "col-sm-12" : "col-sm-2"} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
              <h4 style={{ color: '#fff' }}><span> Online Exam </span> <span style={{ color: 'red' }}> Portal</span> </h4>
            </div>
            <div className={matches1 ? "col-sm-12" : "col-sm-8"} style={{ display: 'flex', justifyContent: 'end', alignItems: 'center' }}>
              <div className="col-sm-12" style={{ padding: '10px 50px 3px 50px' }}>
                <div className="row">

                  <div className='col-sm-5' style={{ display: 'flex', justifyContent: matches2 ? 'end' : 'center', alignItems: 'center', marginLeft: matches2 ? '' : '10px' }}>
                    <h5 style={{ color: '#fff' }}><span style={{ backgroundColor: '#990000', padding: '5px' }}>12:00:00</span><span style={{ backgroundColor: '#606060', padding: '5px' }}>Timer</span> </h5>
                  </div>

                  <div className='col-sm-3' style={{ display: 'flex', justifyContent: matches2 ? 'start' : 'center', alignItems: 'center' }}>

                    <ul className='mt-2' >

                      <li className="dropdown" style={{ listStyle: 'none' }}>
                        <button className=" dropdown-toggle" role="button" data-bs-toggle="dropdown"
                          style={{ backgroundColor: '#990000', color: '#fff', textDecoration: 'none', width: '10rem', display: 'flex', justifyContent: 'start', alignItems: 'center' }}> <img src={exam} /> <span className='mx-2'>Nafis</span>

                        </button>

                      </li>

                    </ul>

                  </div>

                </div>
              </div>
            </div>
            <div >
            </div>

            <div>


            </div>

          </div>
        </div>

      </header>



      {/* .............   .........second row............used...matches 3,4................  ............*/}


      <div className="col-sm-12" style={{ padding: '10px 48px 3px 50px' }}>
        <div className="row" >

          <div className="col-sm-2"></div>
          <div className="col-sm-7" style={{ backgroundColor: 'GrayText', marginLeft: '1rem', border: '4px solid black' }}>

            <div className={matches3 ? "col-sm-12" : "col-sm-10"} style={{ padding: '15px 50px 10px 50px' }}>
              <div className="row">
                <div className={matches4 ? "col-sm-4" : "col-sm-9"} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                  <h6 style={{ color: '#fff' }}><span> Max Marks: 100 </span> </h6>
                </div>

                <div className={matches4 ? "col-sm-4" : "col-sm-9"} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>

                  <h6 style={{ color: '#fff' }}> Exam Name:MBA</h6>
                </div>

                <div className={matches4 ? "col-sm-4" : "col-sm-9"} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }} >
                  <h6 style={{ color: '#fff' }}>Max: 1h-15min  </h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>




      {/* ..................... code...........purpose for practice ..........third row */}



      <div className="col-sm-12" style={{ padding: '10px 32px 3px 65px' }}>
        <div className="row">
          <div className="col-sm-2"></div>
          <div className="col-sm-7" style={{ backgroundColor: 'whitesmoke', border: '4px solid black', marginTop: '-1rem' }}>


            <div className="col-sm-12">
              <div className="row">
                <div className="col-sm-12 mt-1">
                  <div className="row">
                    <div className="col-sm-9" style={{ display: matches6 ? 'block' : 'none', borderRight: matches3 ? '4px solid black' : '', margin: '-.3rem 0rem' }}>
                      <div className="row">
                        {
                          Object.keys(question).length > 0 &&
                          (<>
                            <div className="col-sm-12" style={{ padding: '1rem 2rem 0rem 2rem' }}>
                              <p>{"Q."+numberq+" "+question.question}</p>
                            </div>
                            <div className="col-sm-12" style={{ padding: '0rem 2rem' }}>
                              <div className="row">
                                <div className="col-sm-4">
                                  <div className="form-check form-check-inline" style={{cursor:"pointer"}}>
                                    <input className="form-check-input" checked={question.prev_a_id == question.options[0].a_id ? true : bool1} type="radio" name="inlineRadioOptions" id="inlineRadio1" onClick={() => {
                                      seta_id(question.options[0].a_id);
                                      setbool1(true)
                                      setbool2(false)
                                      setbool3(false)
                                      setbool4(false)
                                      setboolbutton(false)
                                    }} value="option1" />
                                    <label className="form-check-label" style={{cursor:"pointer"}} for="inlineRadio1">  {question.options[0].answer}</label>
                                  </div>
                                </div>
                                <div className="col-sm-1"></div>
                                <div className="col-sm-4">
                                  <div className="form-check form-check-inline" style={{cursor:"pointer"}}>
                                    <input className="form-check-input" type="radio" checked={question.prev_a_id == question.options[1].a_id ? true : bool2} name="inlineRadioOptions" onClick={() => {
                                      seta_id(question.options[1].a_id);
                                      setbool1(false)
                                      setbool2(true)
                                      setbool3(false)
                                      setbool4(false)
                                      setboolbutton(false)
                                    }} id="inlineRadio1" value="option1" />
                                    <label className="form-check-label" style={{cursor:"pointer"}} onClick={() => {
                                      seta_id(question.options[1].a_id);
                                      setbool1(false)
                                      setbool2(true)
                                      setbool3(false)
                                      setbool4(false)
                                      setboolbutton(false)
                                    }} for="inlineRadio2">{question.options[1].answer}</label>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="col-sm-12" style={{ padding: '0rem 2rem' }}>
                              <div className="row">
                                <div className="col-sm-4">
                                  <div className="form-check form-check-inline" style={{cursor:"pointer"}}>
                                    <input className="form-check-input" type="radio" checked={question.prev_a_id == question.options[2].a_id ? true : bool3} name="inlineRadioOptions" id="inlineRadio1" onClick={() => {
                                      seta_id(question.options[2].a_id);
                                      setbool1(false)
                                      setbool2(false)
                                      setbool3(true)
                                      setbool4(false)
                                      setboolbutton(false)
                                    }} value="option1" />
                                    <label className="form-check-label" style={{cursor:"pointer"}} onClick={() => {
                                      seta_id(question.options[2].a_id);
                                      setbool1(false)
                                      setbool2(false)
                                      setbool3(true)
                                      setbool4(false)
                                      setboolbutton(false)
                                    }} for="inlineRadio3">{question.options[2].answer}</label>
                                  </div>
                                </div>
                                <div className="col-sm-1"></div>
                                <div className="col-sm-4">
                                  <div className="form-check form-check-inline" style={{cursor:"pointer"}}>
                                    <input className="form-check-input" type="radio" checked={question.prev_a_id == question.options[3].a_id ? true : bool4} name="inlineRadioOptions" onClick={() => {
                                      seta_id(question.options[3].a_id);
                                      setbool1(false)
                                      setbool2(false)
                                      setbool3(false)
                                      setbool4(true)
                                      setboolbutton(false)
                                    }} id="inlineRadio1" value="option" />
                                    <label className="form-check-label" style={{cursor:"pointer"}} onClick={() => {
                                      seta_id(question.options[3].a_id);
                                      setbool1(false)
                                      setbool2(false)
                                      setbool3(false)
                                      setbool4(true)
                                      setboolbutton(false)
                                    }} for="inlineRadio4">{question.options[3].answer}</label>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </>
                          )


                        }
                      </div>
                    </div>

                    <div className={matches3 ? "col-sm-3" : "col-sm-12"} >
                      <div className='my-2' style={{ fontSize: '.8rem' }}><p>Click on Number to Navigate</p>
                        <div style={{ border: '2px solid red', maxHeight: '100%', maxWidth: '100%', overflowY: !matches3 && matches2 ? "scroll" : "hidden" }}>
                          {q_list.map((item, index) => {
                            return (<button key={index} onClick={()=>{
                              getquestion(item.q_id, qnum, a_id);
                              setnumberq(index + 1);
                            }} style={{ backgroundColor: item.status == 0 ? 'none' : item.status == -1 ? 'red' : 'green', margin: '2px' }} > {index + 1}</button>);
                          })}

                        </div>
                      </div>
                      <div className='my-2' style={{ fontSize: '.8rem' }}><p>Click here to choose Section</p>

                        <div className="col-sm-12" style={{ border: '2px solid black', display: 'flex' }}>



                          <div className="col-sm-6" style={{ margin: '5px' }}>
                            <div className="form-check" >

                              <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked />
                              <label className="form-check-label" for="flexRadioDefault2">
                                Section1
                              </label>
                            </div>

                            <div className="form-check" >

                              <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked />
                              <label className="form-check-label" for="flexRadioDefault2">
                                Section2
                              </label>
                            </div>

                            <div className="form-check" >

                              <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked />
                              <label className="form-check-label" for="flexRadioDefault2">
                                Section3
                              </label>
                            </div>

                            <div className="form-check" >

                              <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked />
                              <label className="form-check-label" for="flexRadioDefault2">
                                Section4
                              </label>
                            </div>




                          </div>
                        </div>
                      </div>


                      <div className='col-sm-12' style={{ fontSize: '.6rem', margin: '15px' }}>
                        <p>Viewed and Attempted</p>
                        <p>Viewed but not Attempted</p>
                        <p>Bookmark and Attempted</p>
                        <p>Bookmark but not Atttempted</p>
                        <p>Not View not Attempted</p>

                      </div>






                    </div>
                  </div>



                </div>

              </div>
            </div>
          </div>

        </div>
      </div>


      <section>

        <div className="col-sm-12" style={{ padding: '10px 32px 0px 65px', }}>
          <div className="row">

            <div className="col-sm-2"></div>
            <div className="col-sm-7" style={{ display: 'flex', backgroundColor: 'gray', border: '4px solid black', marginTop: '-1rem' }}>


              <div className="col-sm-12">
                <div className="row">
                  <div className={matches5 ? 'col-sm-5 my-2' : 'col-sm-12 my-2'} style={{ display: 'flex', justifyContent: matches5 ? 'start' : 'center', alignItems: 'center' }}>
                    <button className='btn btn-warning' disabled={q_list.findIndex((item) => {
                      return item.q_id == qnum
                    }) < 1} style={{ padding: '1px 8px', fontSize: '16px' }} onClick={() => {
                      setskipbool(false);
                      setnum(num - 1);
                      setnumberq(numberq - 1);
                      get_prev_ques(q_list[q_list.findIndex((item) => {
                        return item.q_id == qnum
                      }) - 1].q_id);
                      // setboolbutton(false)
                    }}><span style={para}>Prev</span> </button>
                    <button className='btn btn-primary mx-3' disabled={num === Question.length - 1 || skipbool} style={{ padding: '1px 8px', fontSize: '16px' }} onClick={async () => {
                      if (q_list.findIndex((item) => {
                        return item.q_id == qnum
                      }) === q_list.length - 1) {
                        await axios.post("http://192.168.29.136:8080/api/save_answer", { save_a_id: skip, save_q_id: qnum }).then((res) => {
                          // alert("Submitted Successful")
                          setboolbutton(false)
                          setskipbool(true)
                          if (bool) {
                            setbool(false)
                          }
                          else{
                            get_q_list();
                            setbool(true)
                          }


                        }).catch((err) => {
                          console.log(err);
                        })

                      } else {
                        getquestion(q_list[q_list.findIndex((item) => {
                          return item.q_id == qnum
                        }) + 1].q_id, qnum, skip);
                        setnumberq(numberq + 1);
                      }
                    }}><span style={para}>Skip</span> </button>
                    <button className='btn btn-success mx-3' disabled={boolbutton} style={{ padding: '1px 8px', fontSize: '16px' }} onClick={() => {
                      if (q_list.findIndex((item) => {
                        return item.q_id == qnum
                      }) === q_list.length - 1) {
                        axios.post("http://192.168.29.136:8080/api/save_answer", { save_a_id: a_id, save_q_id: qnum }).then((res) => {
                          if (bool) {
                            finish_exam();
                            setbool(false)
                          }
                          else{
                            get_q_list();
                            setbool(true)
                          }
                        }).catch((err) => {
                          console.log(err);
                        })
                      } else {
                        getquestion(q_list[q_list.findIndex((item) => {
                          return item.q_id == qnum
                        }) + 1].q_id, qnum, a_id);
                          // setboolbutton(true);
                          setnumberq(numberq + 1);
                      }
                    }}><span style={para}> {q_list.findIndex((item) => {
                      return item.q_id == qnum
                    }) === q_list.length - 1 ? "Submit" : 'Save & Next'}  </span></button>
                  </div>
                  <div className={matches5 ? "col-sm-2" : "col-sm-12"} style={{ display: 'flex', justifyContent: matches5 ? 'start' : 'center', alignItems: 'center', color: '#fff' }}>
                    <p className='my-2' style={para}> 1-30 </p>
                  </div>
                  <div className={matches5 ? "col-sm-5" : "col-sm-12"} style={{ display: 'flex', justifyContent: matches5 ? 'start' : 'center', alignItems: 'center' }}>
                    <div className="col-sm-12" style={{ padding: "0px 18px" }}>
                      <div className="row">
                        <div className="col-sm-9 my-2">
                          <button className='btn btn-primary' style={{ padding: '2px 4px' }} onClick={() => {

                          }} ><span style={para}>Exam Summary</span> </button></div>
                        <div className="col-sm-3 my-2" style={{ marginLeft: '-5px' }}>
                          <button className='btn btn-warning' style={{ padding: '2px 4px' }} onClick={() => {

                          }}><span style={para}>Exhibit </span> </button>
                        </div>


                      </div>
                    </div>
                  </div>


                </div>
              </div>
            </div>
          </div>
        </div>

      </section>



      <footer>

        <div className='col-sm-12' style={{ backgroundColor: '#6c6c6c', fontFamily: 'sans-serif', padding: '10px 20px 3px 50px' }}>
          <div className="row">
            <div className="col-sm-2"></div>
            <div className={matches1 ? "col-sm-12" : "col-sm-2"} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
              <h4 style={{ color: '#fff' }}><span> Online Exam </span> <span style={{ color: 'red' }}> Portal</span> </h4>
            </div>

            <div className={matches1 ? "col-sm-12" : "col-sm-8"} style={{ display: 'flex', justifyContent: 'end', alignItems: 'center' }}>
              <div className="col-sm-12" style={{ padding: '10px 50px 3px 50px' }}>
                <div className="row">

                  <div className='col-sm-5' style={{ display: 'flex', justifyContent: matches2 ? 'end' : 'center', alignItems: 'center', marginLeft: matches2 ? '' : '10px' }}>
                    <h5 style={{ color: '#fff' }}><span style={{ padding: '5px', fontSize: '.8rem' }}>Powered By: </span> </h5>
                  </div>

                  <div className='col-sm-3' style={{ display: 'flex', justifyContent: matches2 ? 'start' : 'center', alignItems: 'center' }}>
                    <span >  <img src={infranix} style={{ width: '12rem' }} /> </span>

                  </div>

                </div>
              </div>
            </div>
            <div >
            </div>

            <div>


            </div>

          </div>
        </div>

      </footer>

























    </div>

  )
}

export default HomePage