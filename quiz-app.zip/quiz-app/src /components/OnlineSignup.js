import { Alert, useMediaQuery } from '@mui/material';
import axios from 'axios';
import React, { useContext, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { BASE_URL } from '../Constants';
import Ncontext from '../ContextC';
import infranix from '../Images/infranix.png'
import InstructOnMob from './InstructOnMob';
import "./style.css";


const OnlineSignup = () => {
    const matches1 = useMediaQuery(`(min-width:460px)`);
    const matches2 = useMediaQuery(`(min-width:820px)`);
    const matches3 = useMediaQuery(`(min-width:300px)`);
    const matches4 = useMediaQuery(`(min-width:670px)`);
    const matches5 = useMediaQuery(`(min-width:576px)`);
    let navigate = useNavigate();
    const context = useContext(Ncontext);
    const { sessionId, setsessionId, boolcheck, setboolcheck, min, setmin, sec, setsec  } = context;
    const [name, setname] = useState('');
    const [coupon, setcoupon] = useState('')
    const [email, setemail] = useState('')
    const [mobile, setmobile] = useState('')
    const [bool, setbool] = useState(false);
    const [bool2, setbool2] = useState(false);
    const [bool3, setbool3] = useState(false);
    const [bool4, setbool4] = useState(false);
    const [bool5, setbool5] = useState(false);
    const [bool6, setbool6] = useState(false);
    const [bool7, setbool7] = useState(false);
    const [boolcaptcha, setboolcaptcha] = useState(false);
    // let captcha='';
    const [captcha, setcaptcha] = useState('')
    const alphabets = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz";
    console.log(alphabets.length);
    // let status = document.getElementById('status');
    // status.innerText = "Captcha Generator";



    const generate = () => {
        // console.log(status)
        let first = alphabets[Math.floor(Math.random() * alphabets.length)];
        let second = Math.floor(Math.random() * 10);
        let third = Math.floor(Math.random() * 10);
        let fourth = alphabets[Math.floor(Math.random() * alphabets.length)];
        let fifth = alphabets[Math.floor(Math.random() * alphabets.length)];
        let sixth = Math.floor(Math.random() * 10);
        setcaptcha(first.toString() + second.toString() + third.toString() + fourth.toString() + fifth.toString() + sixth.toString())
        console.log(captcha);
        // document.getElementById('generated-captcha').value = captcha;
        // document.getElementById("entered-captcha").value = '';
        // status.innerText = "Captcha Generator"
    }
    const cookieName = 'countDown';
    const thirtyminutes = 1800;
    var regExp = /[a-zA-Z]/g;
    const instruct = (e) => {
// alert('instruct')
        e.preventDefault();
        // alert("gdsg")
        let userValue = document.getElementById("entered-captcha").value;

        // alert('yes')
        if (name == '' || name == ' ') {
            setbool(true)
        }
        if (email == '' || email == ' ' || !email.includes("@") || !email.includes(".com")) {
            setbool2(true)
        }
        if (!email.includes("@") || !email.includes(".com")) {
            // setbool2(true)
            setbool6(true)
        }
        if (mobile == '' || mobile == ' ' || mobile.length > 10 || regExp.test(mobile)) {
            setbool3(true)
        }
        if (mobile.length > 10) {
            setbool5(true)
        }
        if (regExp.test(mobile)) {
            setbool7(true)
        }
        if (coupon == '' || coupon == ' ') {
            setbool4(true)
        }
        if (email != '' && email != ' ' && coupon != '' && coupon != ' ') {
            // alert('yes')
            if (userValue == captcha) {
                boolcheck == true ?
                axios.get(BASE_URL + "destroy").then((res) => {
                    axios.post(BASE_URL + "api/allot_exam_new", { email: email, coupon_code: coupon }).then((res) => {
                        if (JSON.stringify(typeof (res.data)).includes('string')) {
                            alert(res.data);
                            // generate();
                        } else {
                            localStorage.setItem(cookieName, thirtyminutes);
                            setmin(30);
                            setsec(0);
                            localStorage.setItem('session',res.data.session_id);
                            setsessionId(res.data.session_id);
                            // setemail('')
                            // setcoupon('')
                            navigate("/quiz")
                            // console.log();
                            console.log(res.data.setsessionId);
                        }
                        // alert(JSON.stringify(typeof(res.data)).includes('string'));
                    }).catch((err) => {
                        console.log(err);
                    })

                }).catch((err) => {
                    console.log(err);
                })
                :
                    alert("Please check the condition box")

            } else {
                setboolcaptcha(true)
                console.log(captcha == userValue);
                // alert('Please enter the right captcha');
                generate();
            }

        }


    }



    const check = () => {
        // console.log(status)
        let userValue = document.getElementById("entered-captcha").value;
        console.log(captcha);
        console.log(userValue);
        if (userValue == captcha) {
            // status.innerText = "Correct!!"
        } else {
            // status.innerText = "Try Again!!"
            alert('Please enter the right captcha')
            document.getElementById("entered-captcha").value = '';
        }
    }

    useEffect(() => {
        setboolcheck(false);
        generate()
        // axios.get(BASE_URL + "getSessionValue").then((res) => {
            // if (sessionId !=0) {
            //     navigate('/quiz')
            // }
            // }})
    }, [])


    return (
        <>

            <div className='container-fluid' style={{ margin: 'auto', fontFamily: 'sans-serif', height: "100vh",backgroundColor:"white" }}>


                <div className='col-sm-12' style={{ backgroundColor: '#fff' }}>


                    <div className='mx-4' style={{ padding: '20px 0px' }}>
                        <img src={infranix} width={250} style={{ paddingRight: matches3 ? '0px' : '12px' }} alt="" />

                    </div>

                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: matches2 ? '30px' : '25px', fontSize: matches1 ? '25px' : '22px', fontSize: matches1 ? '30px' : '18px' }}>


                        <div > <b> Stage-1: </b>  </div>

                        <div style={{ marginLeft: '5px' }}> <b> Aptitude Test</b> </div>

                    </div>


                </div>

<div className='col-sm-12' style={{padding:'0px 20px'}}>

                <div className="row">


                    <div className='col-sm-6' style={{ marginTop: '30px' }}>
                        <InstructOnMob />

                    </div>


                    <div className='col-sm-6' style={{ marginTop: '20px' }}>



                        {/* <div className='col-sm-12' style={{ backgroundColor: '#fff' }}>


<div className='mx-4' style={{ padding: '20px 0px' }}>
    <img src={infranix} width={250} style={{ paddingRight: matches3 ? '0px' : '12px' }} alt="" />

</div>


</div> */}

                        <div className='col-sm-12'  >

                            {/* <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: matches2 ? '30px' : '23px', fontSize: matches1 ? '23px' : '20px', fontSize: matches1 ? '30px' : '18px' }}>


    <div > <b> Stage-1: </b>  </div>

    <div style={{ marginLeft: '5px' }}> <b> Aptitude Test</b> </div>

</div> */}


                            <div className="row mt-3" style={{ display: 'flex', justifyContent: 'start', alignItems: 'center', padding: '0px 20px 0px 20px' }}>



                                <div className='col-sm-5' >
                                    <div style={{ fontSize: matches1 ? '20px' : '14px'}}> <b style={{ borderBottom: matches2 ? '2px solid blue' : '2px solid green', color: matches2 ? 'green' : 'blue', whiteSpace: 'nowrap',fontSize: matches4 ? '20px' : '16px'  }}> Please enter details in the form </b> </div>

                                    <form >



                                        <label for="inputEmail4" className="form-label" style={{ margin: '12px 0px' }} >Email </label>
                                        <input type="email" className="form-control" required="true" placeholder='enter the email'
                                            id="inputEmail4" aria-label="email" onChange={(e) => {
                                                setemail(e.target.value)
                                            }} onClick={() => {
                                                setbool2(false);
                                                setbool6(false);
                                                if (name == '' || name == ' ') {
                                                    setbool(true)
                                                }


                                            }} style={{ border: bool6 || bool2 ? "2px solid red" : "1px solid #ced4da", color: bool6 || bool2 ? 'red' : "#212529", width:matches5?'40vw':'100%' }} value={bool2 ? "Please enter the email" : bool6 ? "Please enter a correct email" : email} />







                                        <label for="input tel" className="form-label" style={{ margin: '12px 0px' }}>Coupon</label>
                                        <input type="text" className="form-control" required="true" onChange={(e) => {
                                            setcoupon(e.target.value)
                                        }} placeholder="coupon" onClick={() => {
                                            setbool4(false);
                                            if (name == '' || name == ' ') {
                                                setbool(true)
                                            }
                                            if (email == '' || email == ' ') {
                                                setbool2(true)
                                            }
                                            if (!email.includes("@") || !email.includes(".com")) {
                                                setbool6(true)
                                            }
                                            if (mobile == '' || mobile == ' ' || mobile.length > 10) {
                                                setbool3(true)
                                            }
                                            if (regExp.test(mobile)) {
                                                setbool7(true)
                                            }
                                            if (mobile.length > 10) {
                                                setbool5(true)
                                            }

                                        }} style={{ border: bool4 ? "2px solid red" : "1px solid #ced4da", color: bool4 ? 'red' : "#212529",  width: matches5 ? '40vw' : '100%' }} value={bool4 ? "Please enter the coupon code" : coupon} />


                                        {/* <label for="input tel" className="form-label" style={{ margin: '12px 0px' }}>Captcha</label>

            <input type="text" className="form-control" placeholder="captcha" /> */}



                                        <input type="text" className='mt-4' value={captcha} onChange={()=>{
                                            boolcaptcha(false)
                                        }} readonly id="generated-captcha"></input><span><i class="fa fa-refresh mx-2" onClick={() => {
                                            generate()
                                        }} aria-hidden="true" style={{ fontSize: "25px", cursor: "pointer" }}>
                                        </i></span><span className='mx-2' style={{ color: "red", display: boolcaptcha ? "block" : "none" }}>Enter correct captcha</span><br />


                                        <input type="text" className='mt-3' id="entered-captcha" placeholder="Enter the captcha.." ></input>









                                    </form>
                                </div>


                            </div>
                        </div>


                    </div>




                    {/* <div class="col-sm-12 mt-3" style={{paddingLeft:"40px"}}>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="gridCheck" onChange={()=>{
                  if(boolcheck == false){
                    setboolcheck(true)
                  }
                  else{
                    setboolcheck(false)
                  }
                }} />
                <label class="form-check-label" for="gridCheck" style={{ fontSize: matches1 ? '' : '14px' }}>
                  click on check the box
                </label>
              </div>
            </div> */}
                    <div className='col-sm-12' style={{ display: "flex", justifyContent:matches1?'center': "start", alignItems: "center",paddingLeft:matches1?'':'32px' }}>
                        <button className="btn btn-primary my-5" style={{ width:matches1? "200px":'260px' }} onClick={(e) => {
                            instruct(e)
                        }}>Next</button>
                    </div>
                </div>
                </div>
            </div>

        </>
    )
}

export default OnlineSignup
