import { useMediaQuery } from '@mui/material';
import React, { useContext, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import Ncontext from '../ContextC';
import infranix from '../Images/infranix.png'

const InstructOnMob = () => {

  const matches1 = useMediaQuery(`(min-width:460px)`);
  const matches2 = useMediaQuery(`(min-width:820px)`);
  const matches3 = useMediaQuery(`(min-width:300px)`);
  const matches4 = useMediaQuery(`(min-width:740px)`);
  const matches5 = useMediaQuery(`(min-width:670px)`);

  const context = useContext(Ncontext)
  const {boolcheck, setboolcheck} = context;
  let navigate = useNavigate();
  const allocate_exam = ()=>{
    if (boolcheck) {
      navigate("/quiz")
    } else {
      alert("Please check the condition box")
    }

  }
  return (

    <>

      {/* <div className='col-sm-12' style={{ backgroundColor: '#fff' }}>
        <div className='mx-4' style={{ padding: '20px 0px' }}>
          <img src={infranix} width={230} style={{ paddingRight: matches3 ? '0px' : '12px' }} alt="" />

        </div>

        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: matches2 ? '30px' : '23px', fontSize: matches1 ? '23px' : '20px', fontSize: matches1 ? '30px' : '18px' }}>


          <div > <b> Stage-1: </b>  </div>

          <div style={{ marginLeft: '5px' }}> <b> Aptitude Test</b> </div>

        </div>

      </div> */}






      {/* <div style={{height:'60vh',width:'60vw',border:'1px solid grey',margin:'2rem auto',backgroundColor:'ButtonFace',boxShadow:'5px 5px 5px -2px #333 '}}>  */}


      <div className='container-fluid' style={{ padding: '0px 20px', fontFamily: 'sans-serif'}}>
        <div className="row">




          <div className='col-sm-12'>
            <div  style={{ display: 'flex', justifyContent: 'start', alignItems: 'center'}}>



              <div className='col-sm-12' >
                <div className='my-1' style={{ fontSize: matches1 ? '22px' : '14px' }}> <b style={{ borderBottom: matches2 ? '2px solid blue' : '2px solid green', color: matches2 ? 'green' : 'blue',fontSize:matches5?'20px':'17px' }}> Description </b> </div>

                <div style={{ fontSize: matches1 ? '14px' : '12px' }}>
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry'sLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry'sLorem Ipsum is simply dummy
                </div>


                <div className='mt-2 my-1' style={{ fontSize: matches1 ? '22px' : '14px' }}> <b style={{ borderBottom: matches2 ? '2px solid blue' : '2px solid green', color: matches2 ? 'green' : 'blue',fontSize:matches5?'20px':'17px'  }}> Instruction </b> </div>

                <div style={{ fontSize: matches1 ? '14px' : '12px' }}>
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry'sLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry'sLorem Ipsum is simply dummy
                </div>


              </div>



            </div>


            <div className='col-sm-12 mt-5' style={{ margin: '0', padding: '0' }}>
              <div className='row'>
                <div className='mx-1' style={{ display: 'flex', fontSize: matches4 ? '20px' : '14px'}}>
                  <div className='col-sm-6' style={{ paddingRight: matches1 ? '' : '50px', display: 'flex', justifyContent: 'start', alignItems: 'center' }}> <b>Question:30 </b> </div>
                  <div className='col-sm-6' style={{ paddingLeft: matches1 ? '40px' : '50px',  paddingLeft: matches5 ? '' : '5px',display: 'flex', justifyContent: 'end', alignItems: 'center',whiteSpace:'nowrap' }}> <b> Time:30 Mins</b> </div>


                </div>


              </div>

            </div>


            <div class="col-sm-12 mx-2 mt-2">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="gridCheck" onChange={()=>{
                  if(boolcheck == false){
                    setboolcheck(true)
                  }
                  else{
                    setboolcheck(false)
                  }
                }} />
                <label class="form-check-label" for="gridCheck" style={{ fontSize: matches1 ? '' : '14px' }}>
                  click on check the box
                </label>
              </div>
            </div>

          </div>


          {/* <div className='col-sm-12 text-center' style={{ marginTop: '2rem' }} >

            <span className='btn ' style={{ width: matches1 ? '250px' : '200px', backgroundColor: '#000D83', color: '#fff', fontSize: '.9rem' }} onClick={()=>{
              allocate_exam()
            }}> Next  </span>

          </div> */}
        </div>

      </div>




      {/* </div> */}


    </>
  )

}

export default InstructOnMob







