import axios from 'axios'
  import React, { useState } from 'react'
import { Link } from 'react-router-dom'
  const LoginForm = () => {
  const [email, setemail] = useState(" ")
  const [password, setpassword] = useState("")




  
  const checkData = (e) => {
    e.preventDefault();
    axios.post('http://localhost:1998/login', { email: email, password: password }).then((res) => {
      console.warn(res.data);
      if (res.data.status === 1) {
        window.alert("Login Successfully")

        window.location.href = "/dash"
setemail('');
setpassword('')




      } else {
        window.alert("invalid credentials")
      }







    }).catch((err) => {
      console.warn(err);
    })


  }


  return (
    <div className='container-fluid' style={{ backgroundColor: '#F2FBE9	' }}>
    <div className="row">
<div className="col-sm-4"></div>
 <div className="col-sm-4" style={{display:'flex',justifyContent:'center',alignItems:'center'}}>
    <form>
         <div className="mb-2 mt-4">
           <label for="exampleInputEmail1" className="form-label  mt-5">Email </label>
         <input type="email" className="form-control" value={email} id="exampleInputEmail1" required={true} aria-describedby="emailHelp" placeholder='Enter Email' onChange={(e) => {
            setemail(e.target.value);
          }} />
          <div id="emailHelp" className="form-text">Please fill right email </div>
        </div>
        <div className="mb-3">
          <label for="exampleInputPassword1" className="form-label">Password</label>
          <input type="password" value={password} className="form-control" placeholder='enter password'  required={true}  id="exampleInputPassword1" onChange={(e) => {
            setpassword(e.target.value);
          }} />
        </div>

        <div className="mb-3">
          <Link to="/forget">Forget Password</Link>
        </div>


        <button type="submit" className="btn btn-primary mb-4" onClick={(e) => {
          checkData(e)
        }} >Submit</button>
      </form>

    </div>
    </div>


     </div>




  )
}

export default LoginForm