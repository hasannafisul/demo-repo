// import { useMediaQuery } from 'use-mediaquery'
// import React from 'react'
// import infranix from '../Images/infranix.png'

// const QuizPage = () => {
// const matches1 = useMediaQuery(`(min-width:920px)`);
// const matches2 = useMediaQuery(`(min-width:576px)`);
// const matches3 = useMediaQuery(`(min-width:460px)`);

// let para={
//     fontSize:'16px',
//     padding:'18px'
// }

//     return (
//         <div className='container-fluid ' style={{fontFamily:'sans-serif',height:matches2?'100vh':'100%',margin:0,padding:0,backgroundColor:'#F1F4FB'}}>

//         <div className = 'col-sm-12' style={{backgroundColor:'#fff'}}>


//         <div className='mx-4' style={{padding:'20px 0px'}}>
//         <img src={infranix} width={250} alt=""/>

//         </div>


//         </div>


//      <div className='col-sm-12' style={{display:matches1?'none':'block',backgroundColor:'#fff',boxShadow:' 0px 5px 5px -4px #F1F4FB',marginBottom:'3px'}}>
//         <div className='mx-4'>

//         <div > <span style={{fontSize:'1.5rem',}}> <b> English Quiz </b></span> </div>


// </div>
//         </div>

//  <div className='col-sm-12' style={{padding:'0px 20px',display:matches1?'block':'none',paddingBottom:'15px',backgroundColor:'#fff'}}>
// <div class="row" style={{boxShadow:' 0px 5px 5px -4px #F1F4FB'}}>



// <div className='col-sm-4' style={{display:'flex',justifyContent:'start',alignItems:'center'}}>

// <div > <span style={{fontSize:'1.5rem'}}> <b> English Quiz </b></span> </div>


// </div>


// <div className='col-sm-4' style={{display:'flex',justifyContent:'center',alignItems:'center',}}>

// <span className='mx-2' >Attempts:0/20</span>
//     <span className='mx-2'> Skip:0/20</span>

//     </div>
//     <div className='col-sm-4' style={{display:'flex',justifyContent:'end',alignItems:'center',paddingRight:'50px'}}>



//     <span >Timer:30:00</span>



//     </div>


// </div>
// </div>


// <div className='col-sm-12' style={{padding:'25px 20px',display:matches1?'none':'',backgroundColor:'#fff'}}>
// <div class="row">

// <div className='col-sm-4 ' style={{display:'flex',justifyContent:matches2?'start':'center',alignItems:'center',float:'left',marginLeft:'0px'}}>

// <span className={matches1?'mx-2':''} style={{marginRight:'20px'}}>Attempts:0/20</span>
//     <span className='mx-2'> Skip:0/20</span>

//     </div>
//     <div className='col-sm-8'  style={{marginTop:'5px',display:'flex',justifyContent:matches2?'end':'center',alignItems:'center',float:'right'}}>



//     <span >Timer:30:00</span>



//     </div>


// </div>
// </div>






// <div style={{backgroundColor:'#F1F4FB',marginTop:'-12px'}}>


// <div className='col-sm-12 ' style={{backgroundColor:'#F1F4FB'}}>

// <div className='mx-4' style={{paddingTop:'22px'}}> <span style={{fontSize:'1.5rem'}}> <b> Question : 7 </b> </span> </div>
// <hr/>



// <div className='mx-4'>

// <div style={{display:'flex'}}>

// <div style={{fontSize:'20px'}}></div>

// <div > Who is the Current Prime Minister of india ?  </div>

//  </div>

// <div className="input-group mb-3 my-3" >
// <label className="form-control"   aria-describedby="basic-addon1" style={para}> A: Narendra Modi </label>
//     {/* <span className="input-group-text" id="basic-addon1" style={{backgroundColor:'#fff',borderLeft:'none'}} >
//         <div className="form-check" >
//           <input className="form-check-input"  type="radio" value="" id="flexCheckDefault" />
//         </div>
//     </span> */}
// </div>

// <div className="input-group mb-3 my-3" >
//  <label className="form-control"   aria-describedby="basic-addon1" style={para}>B: Yogi Aditya Nath </label>
//     {/* <span className="input-group-text" id="basic-addon1" style={{backgroundColor:'#fff',borderLeft:'none'}}>
//         <div className="form-check"  >
//           <input className="form-check-input"  type="radio" value="" id="flexCheckDefault" />
//         </div>
//     </span> */}
// </div>

// <div className="input-group mb-3 my-3" >
//  <label className="form-control"   aria-describedby="basic-addon1" style={para}>C: Amit Shah </label>
//     {/* <span className="input-group-text" id="basic-addon1" style={{backgroundColor:'#fff',border:'none'}}>
//         <div className="form-check"  >
//          <input className="form-check-input"  type="radio" value="" id="flexCheckDefault" />
//         </div>
//     </span> */}
// </div>

// <div className="input-group mb-3 my-3" >
//  <label className="form-control"   aria-describedby="basic-addon1" style={para}> D: Rajnath singh  </label>
//     {/* <span className="input-group-text" id="basic-addon1" style={{backgroundColor:'#fff',borderLeft:'none'}}>
//         <div className="form-check"  >
//           <input className="form-check-input"  type="radio" value="" id="flexCheckDefault" />
//         </div>
//     </span> */}
// </div>

// </div>



// </div>




// {/* <div className={matches2?'col-sm-8':'col-sm-4'}></div> */}
// <div className='col-sm-12' style={{display:'flex',justifyContent:matches3?'end':'center',alignItems:'center',padding:'50px 0px'}}>


// <div style={{border:'2px solid #E9E9E9',padding:matches3?'15px 80px':'10px 50px',borderRadius:'15px',marginRight:matches3?'':'10px'}}> <span style={{fontSize:'14px' }}> Skip </span></div>
// <div className={matches3?'mx-5':''}  style={{backgroundColor:'#E9E9E9',padding:matches3?'15px 80px':'10px 50px',borderRadius:'15px',marginLeft:matches3?'':'10px'}}> <span style={{fontSize:'14px',opacity:'.4' }}> Next </span></div>






// </div>

// </div>



//         </div>
//     )
// }

// export default QuizPage