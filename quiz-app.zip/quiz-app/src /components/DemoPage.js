import exam from '../Images/examlogo.png'
import React, { useState, useRef } from 'react';

import logo1 from '../Images/logo1.webp'
import { Num, Question } from './Number'
import useMediaQuery from 'use-mediaquery';

const DemoPage = () => {
    const para = {
        fontSize: '.7rem',
    }
    let border;

    const matches1 = useMediaQuery(`(min-width:820px)`)
    const matches2 = useMediaQuery(`(min-width:1030px)`)
    const matches3= useMediaQuery(`(min-width:576px)`)
    const Ref = useRef(null);
    const [num, setnum] = useState(0);
    let Skiparr = [];


    const [count, setcount] = useState(0)



    return (
        <>

            {/* ..............first row ................................. */}

            <header>

                <div className='col-sm-12' style={{ backgroundColor: 'black', fontFamily: 'sans-serif', padding: '10px 50px 3px 50px' }}>
                    <div className="row">
                        <div className="col-sm-2"></div>
                        <div className="col-sm-2" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <h4 style={{ color: '#fff' }}><span> Online Exam </span> <span style={{ color: 'red' }}> Portal</span> </h4>
                        </div>

                        <div className="col-sm-8" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <div className="col-sm-12" style={{ padding: '10px 50px 3px 50px' }}>
                                <div className="row"  >

                                    <div className='col-sm-5' style={{ display: 'flex', justifyContent: 'end', alignItems: 'center' }}>
                                        <h5 style={{ color: '#fff' }}><span style={{ backgroundColor: '#990000', padding: '5px' }}>12:00:00</span><span style={{ backgroundColor: '#606060', padding: '5px' }}>Timer</span> </h5>
                                    </div>

                                    <div className='col-sm-3' >

                                        <ul className='mt-2' style={{ display: 'flex', justifyContent: 'end', alignItems: 'center' }}>

                                            <li className="dropdown" style={{ listStyle: 'none' }}>
                                                <button className=" dropdown-toggle" role="button" data-bs-toggle="dropdown"
                                                    style={{ backgroundColor: '#990000', color: '#fff', textDecoration: 'none', width: '10rem', display: 'flex', justifyContent: 'start', alignItems: 'center' }}> <img src={exam} /> <span className='mx-2'>Nafis  </span>

                                                </button>

                                            </li>

                                        </ul>

                                    </div>

                                </div>
                            </div>
                        </div>
                        <div >
                        </div>

                        <div>


                        </div>

                    </div>
                </div>

            </header>

{/* .................................................................. */}


            {/* .............   .........second row...............................  ............*/}



 
            <div className="col-sm-12 mt-3" style={{ padding: '10px 32px 3px 65px' }}>
                <div className="row" >

                    <div className="col-sm-2"></div>
                    <div className="col-sm-7" style={{ backgroundColor: 'GrayText', borderLeft: '4px Solid black', borderRight: '4px Solid black', borderTop: '4px solid black' }}>

                        <div className="col-sm-12 " style={{ padding: '1rem 50px 1rem 50px' }}>
                            <div className="row">
                                <div className="col-sm-4" style={{ display: 'flex', justifyContent: 'start', alignItems: 'center' }}>
                                    <h6 style={{ color: '#fff' }}><span> Max Marks: 100 </span> </h6>
                                </div>

                                <div className="col-sm-4" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>

                                    <h6 style={{ color: '#fff' }}> Exam Name:MBA</h6>
                                </div>

                                <div className='col-sm-4' style={{ display: 'flex', justifyContent: 'end', alignItems: 'center' }} >
                                    <h6 style={{ color: '#fff' }}>Max: 1h-15min  </h6>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            {/* .......................Thirsd row.............Para................... */}




 <div className="col-sm-12" style={{ padding: '10px 32px 3px 65px' }}>

                <div className="row">

                    <div className="col-sm-2"></div>
                    <div className="col-sm-7" style={{ backgroundColor: 'smoke', border: '4px solid black', marginTop: '-1rem' }}>


                        <div className="col-sm-12">
                            <div className="row">

                                <div className="col-sm-12 my-1">


                                    <div className="row">




                                        <div className="col-sm-9" style={{ display: matches1 ? 'block' : 'none', borderRight: '4px solid black', margin: '-.3rem 0rem' }}>
                                            <div className="row">

                                                {
                                                    Question.map((item, index) => {

                                                        if (num === index) {

                                                            return (
                                                                <>
                                                                    <div className="col-sm-12" style={{ padding: '1rem 2rem' }}>
                                                                        <p>{item.question}</p>
                                                                    </div>
                                                                    <div className="col-sm-12" style={{ padding: '0rem 3rem' }}>
                                                                        <div className="row">
                                                                            <div className="col-sm-3">
                                                                                <div className="form-check form-check-inline">
                                                                                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                                                                    <label className="form-check-label" for="inlineRadio1">  {item.options.a}</label>
                                                                                </div>
                                                                            </div>
                                                                            <div className="col-sm-3">

                                                                                <div className="form-check form-check-inline">
                                                                                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                                                                    <label className="form-check-label" for="inlineRadio1"> {item.options.b}</label>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>


                                                                    <div className="col-sm-12" style={{ padding: '0rem 3rem' }}>
                                                                        <div className="row">
                                                                            <div className="col-sm-3">
                                                                                <div className="form-check form-check-inline">
                                                                                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                                                                    <label className="form-check-label" for="inlineRadio1"> {item.options.c}</label>
                                                                                </div>
                                                                            </div>

                                                                            <div className="col-sm-3">

                                                                                <div className="form-check form-check-inline">
                                                                                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option" />
                                                                                    <label className="form-check-label" for="inlineRadio1">  {item.options.d}</label>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </>
                                                            )
                                                        }
                                                    })
                                                }



                                            </div>
                                        </div>

                                        <div className="col-sm-3" >
                                            <div className='my-2' style={{ fontSize: '.8rem' }}><p>Click on Number to Navigate</p>
                                                <div style={{ border: '2px solid red', maxHeight: '100%', maxWidth: '100%', overflowY: !matches2 && matches3 ? "scroll" : "hidden" }}>
                                                    {Question.map((item, index) => {
                                                        return (<button key={index} style={{ backgroundColor: Skiparr.includes(index) ? '#3bc43b' : 'none', margin: '2px' }} onClick={() => setnum(index)}> {index + 1}</button>);
                                                    })}

                                                </div>
                                            </div>
                                            <div className='my-2' style={{ fontSize: '.8rem' }}><p>Click here to choose Section</p>

                                                <div className="col-sm-12" style={{ border: '2px solid black', display: 'flex' }}>



                                                    <div className="col-sm-6" style={{ margin: '5px' }}>
                                                        <div className="form-check" >

                                                            <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked />
                                                            <label className="form-check-label" for="flexRadioDefault2">
                                                                Section1
                                                            </label>
                                                        </div>

                                                        <div className="form-check" >

                                                            <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked />
                                                            <label className="form-check-label" for="flexRadioDefault2">
                                                                Section2
                                                            </label>
                                                        </div>

                                                        <div className="form-check" >

                                                            <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked />
                                                            <label className="form-check-label" for="flexRadioDefault2">
                                                                Section3
                                                            </label>
                                                        </div>

                                                        <div className="form-check" >

                                                            <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked />
                                                            <label className="form-check-label" for="flexRadioDefault2">
                                                                Section4
                                                            </label>
                                                        </div>




                                                    </div>
                                                </div>
                                            </div>


                                            <div className='col-sm-12' style={{ fontSize: '.6rem', margin: '15px' }}>

                                                <p>Viewed and Attempted</p>
                                                <p>View but not Attempted</p>
                                                <p>Bookmark and Attempted</p>
                                                <p>Bookmark but not Atttempted</p>
                                                <p>Not View not Attempted</p>

                                            </div>






                                        </div>
                                    </div>



                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div> 







            {/* ..............................fourth row............................... */}










        <section>

                <div className="col-sm-12" style={{ padding: '10px 32px 3px 65px' }}>
                    <div className="row">

                        <div className="col-sm-2"></div>
                        <div className="col-sm-7" style={{ display: 'flex', backgroundColor: 'gray', border: '4px solid black', marginTop: '-1rem' }}>


                            <div className="col-sm-12">
                                <div className="row">



                                    <div className='col-sm-9 my-2' style={{ display: 'flex', justifyContent: 'start', alignItems: 'start' }}>

                                        <button className='btn btn-warning' disabled={num === 0 ? true : false} style={{ padding: '1px 8px', fontSize: '16px' }} onClick={() => {
                                            setnum(num - 1);
                                        }}>Prev</button>
                                        <button className='btn btn-primary mx-3' disabled={num === Question.length - 1} style={{ padding: '1px 8px', fontSize: '16px' }} onClick={() => {
                                            Skiparr[count] = num;
                                            console.log(Skiparr);
                                            setcount(count + 1);
                                            setnum(num + 1);
                                        }}>Skip</button>

                                        <button className='btn btn-success mx-3' style={{ padding: '1px 8px', fontSize: '16px' }} onClick={() => {
                                            if (num === Question.length - 1) {
                                            } else {
                                                setnum(num + 1);
                                            }
                                        }}>{num === Question.length - 1 ? "Submit" : 'Next'} </button>



                                    </div>


                                    <div className="col-sm-3" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                        <div className="col-sm-12">
                                            <div className="row">
                                                <div className="col-sm-8 my-1">
                                                    <button className='btn btn-primary' style={{ padding: '2px 4px' }} onClick={() => {

                                                    }}>Exam Summary</button></div>
                                                <div className="col-sm-4 my-1" style={{ marginLeft: '-5px' }}>
                                                    <button className='btn btn-warning' style={{ padding: '2px 4px' }} onClick={() => {

                                                    }}>Exhibit</button>
                                                </div>


                                            </div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>




            </section>  










        </>
    )
}

export default DemoPage