
import axios from 'axios';
import React, { useState } from 'react';

const Signup = () => {
  const [name, setname] = useState("");
  const [phone, setphone] = useState("")
  const [email, setemail] = useState("")
  const [password, setpassword] = useState("")
  const [confirmpassword, setconfirmpassword] = useState("")
  const [image, setimage] = useState('')
  const [imagename, setimagename] = useState('');
  const [bool, setbool] = useState(false);



  
    const PostData = async (e) => {
      e.preventDefault();
      if (name === '' || phone === '' || email=== '' || password === '' || confirmpassword === '' || image === '') {
        window.alert("please fill data carefully")
      } else{
        
        
        if (password===confirmpassword) {
          
          axios.post("http://localhost:1998/register", { name, email, phone, password, confirmpassword, imagename }).then((res) => {
  setname('')
  setphone('')
  setemail('')
  setpassword("")
  setconfirmpassword('')
  setimagename('')
  
  
  window.alert(res.data.msg)
  
})
.catch((err) => {
  console.log("Invalid Registration");
  console.log(err);
})

} else {
  window.alert('password are not match')
}
}}


  

  const PostSomeData = async (e) => {
    e.preventDefault();
    axios.post("http://localhost:1998/api/emails", { email }).then((res) => {
      if (res.data.status === 0) {
        setbool(true)
      } else {
        setbool(false)
      }
    }).catch((err) => {
      console.log("Invalid Registration");
      console.log(err);
    })

  }

  const handleApi = () => {

    const url = 'http://localhost:1998/api/image'
    const formData = new FormData()
    formData.append('image', image)
    axios.post(url, formData).then((res) => {
      console.log(res.data);


    }).catch((err) => {
      console.log(err);
    })


  }


  const handlechange = (e) => {
    console.log(typeof (e.target.files[0].name))
    setimage(e.target.files[0])
    setimagename(e.target.files[0].name);
  }



  return (
    <div className='container-fluid' style={{ backgroundColor: '#E1F8DC' }}>
      <div className="row">
        <div className="col-sm-3"></div>
        <div className="col-sm-4 mt-5" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <form >


            <label for="input text" className="form-label">Name</label>
            <input type="text" value={name} className="form-control" placeholder="name"  required={true}  aria-label="name"
              onChange={(e) => {
                setname(e.target.value);
              }} />

            <label for="input tel" className="form-label">phone Number</label>
            <input type="Number" value={phone} className="form-control" placeholder="phone number"  required={true}  aria-label="phonenumber"
              onChange={(e) => {
                setphone(e.target.value);
              }} />


            <label for="inputEmail4" className="form-label" >Email </label>
            <input type="email" value={email} className="form-control"  required={true}  placeholder='enter the email' id="inputEmail4" aria-label="email" onChange={(e) => {
              setemail(e.target.value);
            }} style={{marginBottom:'-1rem'}} />

            <label for="inputEmail4" className="form-label" style={{ display: bool ? 'block' : 'none', color: 'red',marginTop:'1rem',marginBottom:'-1rem' }} >Email already exists </label><br />
            <label for="inputPassword4" className="form-label">Password</label>
            <input type="password" value={password} className="form-control"  required={true}  onClick={(e) => {
              PostSomeData(e);
            }} placeholder='enter the password' id="inputPassword4" aria-label="password" onChange={(e) => {
              setpassword(e.target.value);
            }} />


            <label for="inputConfirmPassword4" className="form-label">Confirm Password </label>
            <input type="password" value={confirmpassword} className="form-control"  required={true}  placeholder='confirm password' id="inputPassword4" aria-label="confirmpassword" onChange={(e) => {
              setconfirmpassword(e.target.value)
            }} />


            <label for="file" className="form-label">Upload file</label>
            <input type="file" className="form-control" id="file" aria-label="file"  required={true}  onChange={handlechange} />




            <button type="submit" className="btn btn-primary mb-5 mt-3"
              onClick={(e) => {
                PostData(e);
                handleApi()
              }}>Sign up</button>



          </form>



        </div>
      </div>
    </div>

  )
}

export default Signup

