import React from 'react'

const WelcomPage = () => {
  return (
    <div>
        
<h1>welcome to our Dashboard</h1>





    </div>
  )
}

export default WelcomPage