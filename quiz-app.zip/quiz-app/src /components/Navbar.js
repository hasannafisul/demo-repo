import React from "react"
import { Link } from "react-router-dom"

const Navbar = () => {
  
  return (
    <div>
        
        <nav className="navbar navbar-expand-lg bg-light" style={{position:"fixed",top:'0%',left:'0%',right:'0%',zIndex:'100'}}>
  <div className="container-fluid">
    <Link className="navbar-brand" to="/">Home Page</Link>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
       
       
      </ul>
      
      <form className="d-flex">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">

      <li className="nav-item">
          <Link className="nav-link active" aria-current="page" to="/signup">Registration</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link active" to="/login">Login</Link>
        </li>
            
      </ul>
      </form>
    </div>
  </div>
</nav>





    </div>
  )
}

export default Navbar