
// import { useMediaQuery } from '@mui/material'
// import React, { useState } from 'react'
// import { Num, Question } from './Number'
// const Attempted = () => {

//   const matches1 = useMediaQuery(`(min-width:776px)`)
//   const matches2 = useMediaQuery(`(min-width:586px)`)
//   const matches3 = useMediaQuery(`(min-width:768px)`)

//   const [num, setnum] = useState(0);
//   let Skiparr = [];

//   return (
//     <>

//       <div >



//         <div style={{ border: '8px solid red',height:'280px',width:'350px',margin:'0 auto' }}>
//           {Question.map((item, index) => {
//             return (<button key={index} style={{ backgroundColor: Skiparr.includes(index) ? '#3bc43b' : 'none', height: '45px', width: '45px', margin: '10px', color: 'green', backgroundColor: '#dododo', borderRadius: '8px', border: 'none', fontSize: '12px' }} onClick={() => setnum(index)}> {index + 1}</button>);
//           })}


//         </div>
//       </div>

{/* <div style={{  height:'100%',width:matches2?'360px':'300px',margin:'0 auto'  }}>
                               
                                  
{q_list.map((item, index) => {
    return (
        (
            bool10 &&
            (
                <button key={index} onClick={() => {
                    get_ques_list(item.q_id);
                    setnumberq(index + 1);
                    if (index<q_list.length-1) {
                        setskipbool(false);
                        setbool6(false);
                        setbool(false)
                    }
                }} style={{
                    backgroundColor: item.status == 0 ? '#F2F2F2e' : item.status == -1 ? '#F39F55' : '#3bc43b', border: item.q_id == question.q_id ? "1px solid #1361f9" : "none", height:matches2?'50px':'40px', width:matches2?'50px':'40px', margin: '10px', borderRadius: '8px',color:'red', fontSize:matches2?'14px':'12px', fontWeight: 'bold',
                    boxShadow: " 0 3px 5px -3px #000"
                }} > {index + 1}</button>
            )


        )
    )

   })}
</div> */}



//     </>
//   )
// }

// export default Attempted



// ....................................................Quizpage1................................................................

// import { useMediaQuery } from '@mui/material'
// import infranix from '../Images/infranix.png'
// import React, { useContext, useEffect, useState } from 'react'
// // import { Num, Question } from '../components/Number'
// import "../App.css";
// // import { BASE_URL } from '../Constants';
// import axios from 'axios';
// // import Ncontext from '../ContextC';
// import { useNavigate } from 'react-router-dom';
// import Ncontext from '../ContextC';
// import { BASE_URL } from '../Constants';

// const QuizPage1 = () => {
//     const matches1 = useMediaQuery(`(min-width:860px)`);
//     const matches2 = useMediaQuery(`(min-width:576px)`);
//     const matches3 = useMediaQuery(`(min-width:460px)`);

//     const [num, setnum] = useState(0);
//     let Skiparr = [];

//     const para = {
//         fontSize: '16px',
//         padding: '18px',
//         backgroundColor: '#F8FAFF'
//     }

//     const context = useContext(Ncontext);
//     const { sessionId, setsessionId, min, setmin, sec, setsec } = context;
//     const [value, setvalue] = useState('')
//     let navigate = useNavigate();
//     const [boolbutton, setboolbutton] = useState(true);
//     const [bool, setbool] = useState(false);
//     const [skipbool, setskipbool] = useState(false);
//     const [numberq, setnumberq] = useState(1);
//     const cookieName = 'countDown';
//     const thirtyminutes = 1800;
//     const savedSeconds = localStorage.getItem(cookieName);
//     const startingSeconds = thirtyminutes;
//     // let remainingSeconds = startingSeconds;
//     const [remainingSeconds, setremainingSeconds] = useState(savedSeconds || startingSeconds);
 
//     const [countBool, setcountBool] = useState(false);
//     const countDown = () => {
//         // console.log(savedSeconds)
//         if (countBool == false) {
//             setremainingSeconds(remainingSeconds ? remainingSeconds - 1 : thirtyminutes)
//             localStorage.setItem(cookieName, remainingSeconds);
//             // sec = Math.floor(remainingSeconds / 60);
//             // min = remainingSeconds % 60;
//             setmin(Math.floor(remainingSeconds / 60));
//             setsec(remainingSeconds % 60)
//         }

//     }




//     const finish_exam = () => {
//         setcountBool(true)
//         axios.get(BASE_URL + "destroy").then((res) => {
//             // localStorage.setItem(cookieName, thirtyminutes);
//             setsessionId(0)
//             setTimeout(() => {
//                 localStorage.setItem(cookieName, thirtyminutes)
//                 setremainingSeconds(thirtyminutes);
//                 setmin(30);
//                 setsec(0);
//                 localStorage.setItem('session', 0)
//                 setsessionId(0)
//                 // alert("Submitted Successfully");
//                 navigate('/');
//             }, 500);


//         }).catch((err) => {
//             console.log(err);
//         })
//     }





//     // used for how question


//     //   const [num, setnum] = useState(0);
//     const [count, setcount] = useState(0)
//     //   let Skiparr = [];

//     const body = {
//         backgroundColor: "#6c6c6c"
//     }

//     const [bool1, setbool1] = useState(false);
//     const [bool2, setbool2] = useState(false);
//     const [bool3, setbool3] = useState(false);
//     const [bool4, setbool4] = useState(false);
//     const [bool5, setbool5] = useState(false);
//     const [bool6, setbool6] = useState(false);


//     const [q_list, setq_list] = useState([]);
//     const [question, setquestion] = useState({});
//     const [qnum, setqnum] = useState(0)
//     const [a_id, seta_id] = useState(0)
//     // const [prev_a_id, set_prev_a_id] = useState(0)

//     let skip = -1;
//     let not_attempted = 0;
//     // document.body.requestFullscreen();
//     document.addEventListener('contextmenu', event => event.preventDefault());
//     // document.onkeydown = function (e) {
//     //   // disable F12 key
//     //   if (e.keyCode == 123) {
//     //     return false;
//     //   }
//     //   // disable I key
//     //   if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
//     //     return false;
//     //   }
//     //   // disable J key
//     //   if (e.ctrlKey && e.shiftKey && e.keyCode == 74) {
//     //     return false;
//     //   }
//     //   // disable U key
//     //   if (e.ctrlKey && e.keyCode == 85) {
//     //     return false;
//     //   }
//     // }
//     useEffect(() => {
     
//             if (sessionId != 0) {
//                 // alert(sessionId)
//                 // setsessionId(res.data)
//                 axios.post(BASE_URL + "api/get_question_list", { session_id: sessionId }).then((res) => {
//                     setq_list(res.data)
//                     setqnum(res.data[0].q_id)
//                     axios.post(BASE_URL + "api/get_question", { q_id: res.data[0].q_id }).then((res) => {
//                         console.log(res.data);
//                         setquestion(res.data);
//                     }).catch((err) => {
//                         console.log(err);
//                     })
//                 }).catch((err) => {
//                     console.log(err);
//                 })
//             }
//             else {
//                 window.location.href = '/'
//             }
      
//     }, [])

//     // useEffect(() => {
//     //         countDown()
//     // }, )

//     const get_q_list = () => {
//         axios.post(BASE_URL + "api/get_question_list", { session_id: sessionId }).then((res) => {
//             setq_list(res.data)
//             // console.log(res.data);
//         }).catch((err) => {
//             console.log(err);
//         })
//     }


//     const getquestion = (q_number, qnumprev, aid) => {
//         setqnum(q_number);
//         axios.post(BASE_URL + "api/get_question", { q_id: q_number, save_a_id: aid, save_q_id: qnumprev }).then((res) => {
//             setquestion(res.data);
//             console.log(res.data.prev_a_id);
//             seta_id(res.data.prev_a_id)
//             setbool1(res.data.prev_a_id == res.data.options[0].a_id ? true : false);
//             setbool2(res.data.prev_a_id == res.data.options[1].a_id ? true : false);
//             setbool3(res.data.prev_a_id == res.data.options[2].a_id ? true : false);
//             setbool4(res.data.prev_a_id == res.data.options[3].a_id ? true : false);
//             setboolbutton(res.data.prev_a_id == 0 || res.data.prev_a_id == -1 ? true : false);
//             get_q_list();
//         }).catch((err) => {
//             console.log(err);
//         })
//     }

//     const get_ques_list = (q_number) => {
//         setqnum(q_number)
//         axios.post(BASE_URL + "api/get_question", { q_id: q_number }).then((res) => {
//             seta_id(res.data.prev_a_id)
//             setquestion(res.data);
//             setbool1(res.data.prev_a_id == res.data.options[0].a_id ? true : false);
//             setbool2(res.data.prev_a_id == res.data.options[1].a_id ? true : false);
//             setbool3(res.data.prev_a_id == res.data.options[2].a_id ? true : false);
//             setbool4(res.data.prev_a_id == res.data.options[3].a_id ? true : false);
//             // get_q_list();
//             setboolbutton(res.data.prev_a_id == 0 || res.data.prev_a_id == -1 ? true : false);
//         }).catch((err) => {
//             console.log(err);
//         })
//     }

//     const [unattemptedques, setunattemptedques] = useState(0);

//     const [bool7, setbool7] = useState(false);
//     const [bool8, setbool8] = useState(false);
//     const [bool9, setbool9] = useState(false);
//     const [bool10, setbool10] = useState(true);
//     const [bool11, setbool11] = useState(false);
//     const [q_status, setq_status] = useState(0);

//     setTimeout(() => {
//         countDown()
//     }, 1000);

//     return (
//         <>

//             <div className='col-sm-12 font' style={{ padding: '0px 0px', backgroundColor: '#F8FAFF' }}>




//                 <div className='' style={{ padding: '20px 20px', margin: '0', backgroundColor: '#fff' }}>
//                     <img src={infranix} width={250} alt="" />

//                 </div>
//                 <div style={{ padding: '0px 20px', display: matches1 ? 'none' : 'block', backgroundColor: '#fff', boxShadow: ' 0px 5px 5px -4px #F1F4FB', marginBottom: '3px' }}>

//                     <div> <span style={{ fontSize: '1.5rem', }}> <b> English Quiz </b></span> </div>


//                 </div>

//                 <div className='col-sm-12 ' style={{ padding: '0px 20px', display: matches1 ? 'block' : 'none', backgroundColor: '#fff' }}>
//                     <div class="row" style={{ boxShadow: ' 0px 5px 5px -4px #F1F4FB', borderBottomLeftRadius: '20px', borderBottomRightRadius: '20px' }}>



//                         <div className='col-sm-4' style={{ display: 'flex', justifyContent: 'start', alignItems: 'center' }}>

//                             <div > <span style={{ fontSize: '1.5rem' }}> <b> English Quiz </b></span> </div>


//                         </div>


//                         <div className='col-sm-4' style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>

//                             <span className='mx-2' >Attempts:{" "+q_list.filter((item)=>{
//                                 if (item.status !=0 && item.status != -1) {
//                                     return item
//                                 }
//                             }).length+"/"+q_list.length}</span>
//                             <span className='mx-2' style={{whiteSpace:'nowrap'}}> Skip:{" "+q_list.filter((item)=>{
//                                 if (item.status == -1) {
//                                     return item
//                                 }
//                             }).length+"/"+q_list.length}</span>

//                         </div>
//                         <div className='col-sm-4' style={{ display: 'flex', justifyContent: 'end', alignItems: 'center', paddingRight: '50px' }}>



//                             <span >Timer:{min < 10 ? "0" + min : min}{sec < 10 ? ":0" + sec : ":" + sec}</span>



//                         </div>


//                     </div>
//                 </div>


//                 <div className='col-sm-12' style={{ padding: '25px 20px', display: matches1 ? 'none' : '', backgroundColor: '#fff' }}>
//                     <div class="row">

//                         <div className='col-sm-4 ' style={{ display: 'flex', justifyContent: matches2 ? 'start' : 'center', alignItems: 'center', float: 'left', marginLeft: '0px' }}>

//                             <span className={matches1 ? 'mx-2' : ''} style={{ marginRight: '20px',whiteSpace:'nowrap' }}>Attempts:{" "+q_list.filter((item)=>{
//                                 if (item.status !=0 && item.status != -1) {
//                                     return item
//                                 }
//                             }).length+"/"+q_list.length}</span>
//                             <span className='mx-2' style={{whiteSpace:'nowrap'}}> Skip:{" "+q_list.filter((item)=>{
//                                 if (item.status == -1) {
//                                     return item
//                                 }
//                             }).length+"/"+q_list.length}</span>

//                         </div>
//                         <div className='col-sm-8' style={{ marginTop: '5px', display: 'flex', justifyContent: matches2 ? 'end' : 'center', alignItems: 'center', float: 'right' }}>



//                             <span >Timer:{min < 10 ? "0" + min : min}{sec < 10 ? ":0" + sec : ":" + sec}</span>



//                         </div>


//                     </div>
//                 </div>


//                 <div className='col-sm-12' style={{ padding: '0px 20px', marginTop: '35px' }}>

//                     <div className='row'>
//                         <div className='col-sm-4' style={{ display: matches3 ? 'block' : 'none',display:matches1?'block':'none' }}>


//                             <div className='col-sm-10 text-center' style={{ paddingLeft: "20px" }}>

//                                 <div style={{ fontFamily: 'robot', paddingLeft: "10px" }}>
//                                     <div style={{ display: "flex", justifyContent: "start", alignItems: "center" }}>
//                                         <input className="form-check-input mt-0 mx-1" type="checkbox" value="" checked={bool10} onClick={() => {
//                                             setbool8(false);
//                                             setbool7(false);
//                                             setbool9(false);
//                                             setbool10(true);
//                                             setbool11(false)
//                                         }} style={{ border: "2px solid #1361f9" }} /><span> All</span>
//                                     </div>
//                                     <div style={{ display: "flex" }}>
//                                         <div style={{ display: "flex", justifyContent: "start", alignItems: "center" }}>
//                                             <input className="form-check-input mt-0 mx-1" type="checkbox" value="" checked={bool8} onChange={() => {
//                                                 if (bool8 == false) {
//                                                     setbool8(true);
//                                                     setbool7(false);
//                                                     setbool9(false);
//                                                     setbool10(false);
//                                                     setbool11(false)

//                                                 } else {
//                                                     setbool8(false);
//                                                     setbool7(false);
//                                                     setbool9(false);
//                                                     setbool10(true);
//                                                     setbool11(false)
//                                                 }
//                                             }} style={{ border: "3px solid #F39F55" }} /><span style={{color:"#F39F55"}}> Skipped</span>
//                                         </div>
//                                         <div className='mx-1' style={{ display: "flex", justifyContent: "start", alignItems: "center" }}>
//                                             <input className="form-check-input mt-0 mx-1" type="checkbox" value="" checked={bool9} onChange={() => {
//                                                 if (bool9 == false) {
//                                                     setbool8(false);
//                                                     setbool7(false);
//                                                     setbool9(true);
//                                                     setbool10(false);
//                                                     setbool11(false)

//                                                 } else {
//                                                     setbool8(false);
//                                                     setbool7(false);
//                                                     setbool9(false);
//                                                     setbool10(true);
//                                                     setbool11(false)
//                                                 }
//                                             }} style={{ border: "3px solid green" }} /><span style={{color:"green"}}> Attempted</span>
//                                         </div>
//                                         <div style={{ display: "flex", justifyContent: "start", alignItems: "center" }}>
//                                             <input className="form-check-input mt-0 mx-1" type="checkbox" checked={bool7} onChange={() => {
//                                                 if (bool7 == false) {
//                                                     setbool8(false);
//                                                     setbool7(true);
//                                                     setbool9(false);
//                                                     setbool10(false);
//                                                     setbool11(false)
//                                                 } else {
//                                                     setbool8(false);
//                                                     setbool7(false);
//                                                     setbool9(false);
//                                                     setbool10(true);
//                                                     setbool11(false)
//                                                 }

//                                             }} value="" /><span> Not Attempted</span>
//                                         </div>
//                                     </div>
//                                 </div>


//                                 <div className='mt-4 overflownum ' style={{ border: '2px solid #E9E9E9', padding: '10px', borderRadius: '25px' }}>
                               
//                                     {q_list.map((item, index) => {
//                                         return (
//                                             (
//                                                 bool7 &&
//                                                 item.status == 0 &&
//                                                 (
//                                                     <button key={index} onClick={() => {
//                                                         get_ques_list(item.q_id);
//                                                         setnumberq(index + 1);
//                                                         if (index<q_list.length-1) {
//                                                             setskipbool(false);
//                                                             setbool6(false);
//                                                             setbool(false)
//                                                         }
//                                                     }} style={{
//                                                         backgroundColor: item.status == 0 ? '#F2F2F2e' : item.status == -1 ? '#F39F55' : '#3bc43b', border: item.q_id == question.q_id ? "1px solid #1361f9" : "none", height: '50px', width: '50px', margin: '10px', borderRadius: '8px', fontSize: '14px', fontWeight: 'bold',
//                                                         boxShadow: " 0 3px 5px -3px #000"
//                                                     }} > {index + 1}</button>
//                                                 )

                                                
//                                             )
//                                         )

                                        
//                                     })}
//                                     {q_list.map((item, index) => {
//                                         return (
//                                             (
//                                                 bool8 &&
//                                                 item.status == -1 &&
//                                                 (
//                                                     <button key={index} onClick={() => {
//                                                         get_ques_list(item.q_id);
//                                                         setnumberq(index + 1);
//                                                         if (index<q_list.length-1) {
//                                                             setskipbool(false);
//                                                             setbool6(false);
//                                                             setbool(false)
//                                                         }
//                                                     }} style={{
//                                                         backgroundColor: item.status == 0 ? '#F2F2F2e' : item.status == -1 ? '#F39F55' : '#3bc43b', border: item.q_id == question.q_id ? "1px solid #1361f9" : "none", height: '50px', width: '50px', margin: '10px', borderRadius: '8px', fontSize: '14px', fontWeight: 'bold',
//                                                         boxShadow: " 0 3px 5px -3px #000"
//                                                     }} > {index + 1}</button>
//                                                 )


//                                             )
//                                         )

//                                         // return (<button key={index} onClick={() => {
//                                         //     get_ques_list(item.q_id);
//                                         //     setnumberq(index + 1);
//                                         // }} style={{ backgroundColor: item.status == 0 ? 'none' : item.status == -1 ? '#F39F55' : '#3bc43b', border: item.q_id == question.q_id ? "1px solid #1361f9" : "none", height: '70px', width: '70px', margin: '10px', borderRadius: '8px', fontSize: '14px', fontWeight: 'bold' }} > {index + 1}</button>);
//                                     })}
//                                     {q_list.map((item, index) => {
//                                         return (
//                                             (
//                                                 bool9 &&
//                                                 item.status != -1 && item.status != 0 &&
//                                                 (
//                                                     <button key={index} onClick={() => {
//                                                         get_ques_list(item.q_id);
//                                                         setnumberq(index + 1);
//                                                         if (index<q_list.length-1) {
//                                                             setskipbool(false);
//                                                             setbool6(false);
//                                                             setbool(false)
//                                                         }
//                                                     }} style={{
//                                                         backgroundColor: item.status == 0 ? '#F2F2F2e' : item.status == -1 ? '#F39F55' : '#3bc43b', border: item.q_id == question.q_id ? "1px solid #1361f9" : "none", height: '50px', width: '50px', margin: '10px', borderRadius: '8px', fontSize: '14px', fontWeight: 'bold',
//                                                         boxShadow: " 0 3px 5px -3px #000"
//                                                    }} > {index + 1}</button>
//                                                 )


//                                             )
//                                         )

//                                         // return (<button key={index} onClick={() => {
//                                         //     get_ques_list(item.q_id);
//                                         //     setnumberq(index + 1);
//                                         // }} style={{ backgroundColor: item.status == 0 ? 'none' : item.status == -1 ? '#F39F55' : '#3bc43b', border: item.q_id == question.q_id ? "1px solid #1361f9" : "none", height: '70px', width: '70px', margin: '10px', borderRadius: '8px', fontSize: '14px', fontWeight: 'bold' }} > {index + 1}</button>);
//                                     })}
//                                     {q_list.map((item, index) => {
//                                         return (
//                                             (
//                                                 bool10 &&
//                                                 (
//                                                     <button key={index} onClick={() => {
//                                                         get_ques_list(item.q_id);
//                                                         setnumberq(index + 1);
//                                                         if (index<q_list.length-1) {
//                                                             setskipbool(false);
//                                                             setbool6(false);
//                                                             setbool(false)
//                                                         }
//                                                     }} style={{
//                                                         backgroundColor: item.status == 0 ? '#F2F2F2e' : item.status == -1 ? '#F39F55' : '#3bc43b', border: item.q_id == question.q_id ? "1px solid #1361f9" : "none", height: '50px', width: '50px', margin: '10px', borderRadius: '8px', fontSize: '14px', fontWeight: 'bold',
//                                                         boxShadow: " 0 3px 5px -3px #000"
//                                                     }} > {index + 1}</button>
//                                                 )


//                                             )
//                                         )

//                                         // return (<button key={index} onClick={() => {
//                                         //     get_ques_list(item.q_id);
//                                         //     setnumberq(index + 1);
//                                         // }} style={{ backgroundColor: item.status == 0 ? 'none' : item.status == -1 ? 'red' : '#3bc43b', border: item.q_id == question.q_id ? "1px solid #1361f9" : "none", height: '70px', width: '70px', margin: '10px', borderRadius: '8px', fontSize: '14px', fontWeight: 'bold' }} > {index + 1}</button>);
//                                     })}
//                                 </div>




//                             </div>

//                         </div>




// {/* ........................................question Area....................................................... */}


//                         <div className={matches1?'col-sm-7':'col-sm-12'}>


//                             <div className='container-fluid ' style={{ height: matches2 ? '100vh' : '100%', margin: 0, padding: 0, }}>


//                                 <div style={{ marginTop: '-12px' }}>


//                                     <div className='col-sm-12 '>
//                                         {
//                                             Object.keys(question).length > 0 &&
//                                             (<>
                                               
//                                                 <div className='mx-4' style={{ paddingTop: '5px' }}> <span style={{ fontSize: '1.5rem' }}> <b> Question : {numberq} </b> </span> </div>
//                                                 <hr />
//                                                 <div className='mx-4'>

//                                                     <div style={{ display: 'flex' }}>
//                                                         {
//                                                             question.q_type == 1 ? (
//                                                                 <div style={{ fontSize: '20px' }}>

//                                                                     {question.question + " ?"}
//                                                                 </div>
//                                                             ) : (
//                                                                 <img className='my-2' src={question.question} style={{ height: "120px", width: "120px" }} />
//                                                             )
//                                                         }


                    

//                                                     </div>

//                                                     <div style={{ display: 'flex' }}>



//                                                         {
//                                                             question.answer_img == "" ? (
//                                                                 ""
//                                                             ) : (
//                                                                 <img className='mt-2' src={question.answer_img} />
//                                                             )
//                                                         }

                                                       

//                                                     </div>
//                                                     <div className="input-group mb-3 my-3" onClick={() => {


//                                                     }}>
//                                                         <label className="form-control" aria-describedby="basic-addon1" style={{
//                                                             fontSize: '16px',
//                                                             padding: '14px',
//                                                             cursor: 'pointer',
//                                                             backgroundColor: bool1 ? "#3bc43b" : "#F2F2F2",
//                                                             boxShadow: " 0 3px 5px -3px #000" ,
                                                            
                                                            
//                                                             backgroundColor:'blue'
//                                                         }} onClick={() => {
//                                                             seta_id(question.options[0].a_id);
//                                                             setbool1(true)
//                                                             setbool2(false)
//                                                             setbool3(false)
//                                                             setbool4(false)
//                                                             setboolbutton(false)
//                                                             setskipbool(false);
//                                                         }}> A: {question.options[0].answer} </label>
//                                                     </div>

//                                                     <div className="input-group mb-3 my-3" onClick={() => {

//                                                     }} >
//                                                         <label className="form-control" aria-describedby="basic-addon1" style={{
//                                                             fontSize: '16px',
//                                                             padding: '14px',
//                                                             cursor: 'pointer',
//                                                             backgroundColor: bool2 ? "#3bc43b" : "#F2F2F2",
//                                                             boxShadow: " 0 3px 5px -3px #000"
                                                            
                                                            
//                                                         }} onClick={() => {
//                                                             seta_id(question.options[1].a_id);
//                                                             setbool1(false)
//                                                             setbool2(true)
//                                                             setbool3(false)
//                                                             setbool4(false)
//                                                             setboolbutton(false)
//                                                             setskipbool(false);
//                                                         }}>B: {question.options[1].answer} </label>
//                                                     </div>

//                                                     <div className="input-group mb-3 my-3" onClick={() => {

//                                                     }} >
//                                                         <label className="form-control" aria-describedby="basic-addon1" style={{
//                                                             fontSize: '16px',
//                                                             padding: '14px',
//                                                             cursor: 'pointer',
//                                                             backgroundColor: bool3 ? "#3bc43b" : "#F2F2F2",
//                                                             boxShadow: " 0 3px 5px -3px #000"
//                                                         }} onClick={() => {
//                                                             seta_id(question.options[2].a_id);
//                                                             setbool1(false)
//                                                             setbool2(false)
//                                                             setbool3(true)
//                                                             setbool4(false)
//                                                             setboolbutton(false)
//                                                             setskipbool(false);
//                                                         }}>C: {question.options[2].answer} </label>
//                                                     </div>

//                                                     <div className="input-group mb-3 my-3" onClick={() => {

//                                                     }} >
//                                                         <label className="form-control" aria-describedby="basic-addon1" style={{
//                                                             fontSize: '16px',
//                                                             padding: '14px',
//                                                             cursor: 'pointer',
//                                                             backgroundColor: bool4 ? "#3bc43b" : "#F2F2F2",
//                                                             boxShadow: " 0 3px 5px -3px #000"
//                                                         }} onClick={() => {
//                                                             seta_id(question.options[3].a_id);
//                                                             setbool1(false)
//                                                             setbool2(false)
//                                                             setbool3(false)
//                                                             setbool4(true)
//                                                             setboolbutton(false)
//                                                             setskipbool(false);
//                                                         }}> D: {question.options[3].answer}  </label>
//                                                     </div>

//                                                 </div>
//                                             </>
//                                             )


//                                         }
                                      


//                                     </div>




//                                     <div className='col-sm-12' style={{ display: 'flex', justifyContent: matches3 ? 'end' : 'center', alignItems: 'center', paddingTop: '25px' ,paddingBottom:'40px' }}>


//                                         <button disabled={skipbool} style={{ boxShadow: !skipbool?" 0 3px 5px -3px #000":"none",border: '2px solid #E9E9E9', padding: matches3 ? '10px 50px' : '9px 40px', borderRadius:matches3? '15px':'18px', marginRight: matches3 ? '' : '10px' }} onClick={async () => {
//                                             if (q_list.findIndex((item) => {
//                                                 return item.q_id == qnum
//                                             }) === q_list.length - 1) {
//                                                 await axios.post(BASE_URL + "api/save_answer", { save_a_id: skip, save_q_id: qnum }).then((res) => {
                                                   
//                                                     setboolbutton(false)
//                                                     setskipbool(true)
//                                                     if (bool) {
//                                                         setbool(false)
//                                                     }
//                                                     else {
//                                                         get_q_list();
//                                                         setbool(true)
//                                                     }


//                                                 }).catch((err) => {
//                                                     console.log(err);
//                                                 })

//                                             } else {
//                                                 getquestion(q_list[q_list.findIndex((item) => {
//                                                     return item.q_id == qnum
//                                                 }) + 1].q_id, qnum, skip);
//                                                 setnumberq(numberq + 1);
//                                             }
//                                         }}> <span style={{ fontSize:matches3? '14px':'12px' }} > Skip </span></button>
//                                         <button className={matches3 ? 'mx-5' : ''} disabled={boolbutton} type="button" data-bs-toggle="modal" data-bs-target={bool5 ? "#staticBackdrop" : ""} style={{  boxShadow: !boolbutton?" 0 3px 5px -3px #000":"none",border: "none", padding: matches3 ? '12px 50px' : '10px 30px', borderRadius:matches3? '15px':'18px', marginLeft: matches3 ? '' : '20px' }} onClick={() => {

//                                             if (bool5 == false) {
//                                                 if (q_list.findIndex((item) => {
//                                                     return item.q_id == qnum
//                                                 }) === q_list.length - 1) {
//                                                     axios.post(BASE_URL + "api/save_answer", { save_a_id: a_id, save_q_id: qnum }).then((res) => {
//                                                         if (bool) {
//                                                             get_q_list();
                                                          
//                                                             setbool5(true);
//                                                             var res = q_list.reduce(function (obj, v) {
//                                                                 obj[v.status] = (obj[v.status] || 0) + 1;
//                                                                 return obj;
//                                                             }, {})
//                                                             if (res[0] > 0) {
//                                                                 setbool6(true);
                                                              
//                                                                 q_list.filter((item, index) => {
//                                                                     if (item.status == 0) {
//                                                                         setnum(index + 1)
//                                                                         return item;
//                                                                     }
//                                                                 }).map((item, index) => {
//                                                                     setunattemptedques(item.q_id);

//                                                                 })

//                                                             } else {
//                                                                 setbool6(false);
//                                                             }
//                                                         }
//                                                         else {
//                                                             get_q_list();
//                                                             setbool(true)
//                                                         }
//                                                     }).catch((err) => {
//                                                         console.log(err);
//                                                     })
//                                                 } else {
//                                                     getquestion(q_list[q_list.findIndex((item) => {
//                                                         return item.q_id == qnum
//                                                     }) + 1].q_id, qnum, a_id);
                                                   
//                                                     setnumberq(numberq + 1);
//                                                     if (bool11) {
//                                                         setbool8(false);
//                                                         setbool7(false);
//                                                         setbool9(false);
//                                                         setbool10(true)
//                                                     }
//                                                 }
//                                             }
//                                         }}> <span style={{ fontSize:matches3?'14px':'12px',whiteSpace:'nowrap' }}> {bool ? "Submit" : 'Save & Next'} </span></button>


//                                         <div class="modal" id="staticBackdrop" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
//                                             <div class="modal-dialog modal-dialog-centered">
//                                                 <div class="modal-content">
//                                                     <div class="modal-header">
//                                                         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
//                                                     </div>
//                                                     <div class="modal-body">
//                                                         {!bool6 ? "Do you want to submit?" : "You have not attempted all questions. Do you want to finsish the test?"}
//                                                     </div>
//                                                     <div class="modal-footer">
//                                                         <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onClick={() => {
//                                                             setbool(false);
//                                                             setbool5(false);
//                                                             setskipbool(false);
                                                            
//                                                             if (bool6) {
//                                                                 get_ques_list(unattemptedques);
//                                                                 setnumberq(num);
//                                                                 setbool8(false);
//                                                                 setbool7(true);
//                                                                 setbool9(false);
//                                                                 setbool10(false);
//                                                                 setbool11(true);
//                                                                 setbool6(false);
//                                                             }

//                                                         }}>No</button>
//                                                         <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#lastModal" >Yes</button>
//                                                     </div>
//                                                 </div>
//                                             </div>
//                                         </div>
//                                         <div class="modal" id="lastModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
//                                             <div class="modal-dialog modal-dialog-centered">
//                                                 <div class="modal-content">
//                                                     <div class="modal-header">

//                                                     </div>
//                                                     <div class="modal-body">
//                                                         Thank you for your participation. We will notify your result soon.
//                                                     </div>
//                                                     <div class="modal-footer">
//                                                         <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onClick={() => {
//                                                             finish_exam();
//                                                         }}>OK</button>
//                                                     </div>
//                                                 </div>
//                                             </div>
//                                         </div>

//                                     </div>

//                                 </div>



//                             </div>







//                         </div>












//                     </div>
//                 </div>

//             </div>



//         </>
//     )
// }

// export default QuizPage1
