// import { useMediaQuery } from 'use-mediaquery'
// import React, { useState } from 'react'
// import { Num, Question } from './Number'
// const QuesOnMobile = () => {


//     const matches1 = useMediaQuery(`(min-width:920px)`)
//     const matches2 = useMediaQuery(`(min-width:768px)`)
//     const matches3 = useMediaQuery(`(min-width:576px)`)




//     const [num, setnum] = useState(0);
//     let Skiparr = [];
//     const [count, setcount] = useState(0)


//   return (
//     <div className='container-fluid'>


//         <div className="col-sm-12" style={{display:'flex',justifyContent:'center',alignItems:'center'}}>
//                             <div className="row">

//                                 {
//                                     Question.map((item, index) => {

//                                         if (num === index) {

//                                             return (
//                                                 <>
//                                                     <div className="col-sm-12" style={{ padding: '1rem 2rem' }}>
//                                                         <p>{item.question}</p>
//                                                     </div>
//                                                     <div className="col-sm-12" style={{ padding: '0rem 3rem' }}>
//                                                         <div className="row">
//                                                             <div className="col-sm-4">
//                                                                 <div className="form-check form-check-inline">
//                                                                     <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
//                                                                     <label className="form-check-label" for="inlineRadio1">  {item.options.a}</label>
//                                                                 </div>
//                                                             </div>
//                                                             <div className="col-sm-4">

//                                                                 <div className="form-check form-check-inline">
//                                                                     <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
//                                                                     <label className="form-check-label" for="inlineRadio1"> {item.options.b}</label>
//                                                                 </div>
//                                                             </div>
//                                                         </div>
//                                                     </div>


//                                                     <div className="col-sm-12" style={{ padding: '0rem 3rem' }}>
//                                                         <div className="row">
//                                                             <div className="col-sm-4">
//                                                                 <div className="form-check form-check-inline">
//                                                                     <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
//                                                                     <label className="form-check-label" for="inlineRadio1"> {item.options.c}</label>
//                                                                 </div>
//                                                             </div>
//                                                             <div className="col-sm-4">

//                                                                 <div className="form-check form-check-inline">
//                                                                     <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option" />
//                                                                     <label className="form-check-label" for="inlineRadio1">  {item.options.d}</label>
//                                                                 </div>
//                                                             </div>
//                                                         </div>
//                                                     </div>

//                                                 </>
//                                             )
//                                         }
//                                     })
//                                 }



//                             </div>
//                         </div> 



//                         <div className='mt-5' style={{textAlign:'center'}}>

//                         <span  className='mx-3' disabled={num === Question.length - 1} style={{ width:'50%',fontSize:'.9rem'}} onClick={() => {
//                                         Skiparr[count] = num;
//                                         console.log(Skiparr);
//                                         setcount(count + 1);
//                                         setnum(num + 1);
//                                     }}>Skip</span>

// </div>


//                         <div className='mt-3' style={{textAlign:'center'}}>

// <button className='btn btn-success mx-3' style={{width:'50%',backgroundColor:'#000080',color:'#fff',borderRadius:'15px',fontSize:'.9rem',boxShadow:'none' }} onClick={() => {
//                                             if (num === Question.length - 1) {
//                                             } else {
//                                                 setnum(num + 1);
//                                             }
//                                         }}>{num === Question.length - 1 ? "Submit" : 'Next'} </button>


// </div>





//     </div>
//   )
// }

// export default QuesOnMobile


// ......................................................................//

import { useMediaQuery } from 'use-mediaquery'
import React, { useState } from 'react'
import { Num, Question } from './Number'
const QuesOnMobile = () => {


    const matches1 = useMediaQuery(`(min-width:920px)`)
    const matches2 = useMediaQuery(`(min-width:768px)`)
    const matches3 = useMediaQuery(`(min-width:576px)`)




    const [num, setnum] = useState(0);
    let Skiparr = [];
    const [count, setcount] = useState(0)
    const [bool1, setbool1] = useState(false)
    const [bool2, setbool2] = useState(false)
    const [bool3, setbool3] = useState(false)
    const [bool4, setbool4] = useState(false)


   

    return (
        <div className='container-fluid'>


            <div className="col-sm-12" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <div className="row">

                    {
                        Question.map((item, index) => {

                            if (num === index) {

                                return (
                                    <>
                                        <div className="col-sm-12" style={{ padding: '1rem 2rem' }}>
                                            <p>{item.question}</p>
                                        </div>
                                        <div className="col-sm-12" style={{ padding: '0rem 3rem' }}>
                                            <div className="row">
                                                <div className="col-sm-4">

                                                    <div className="input-group mb-3" >
                                                        <label className="form-control" aria-describedby="basic-addon1" style={{backgroundColor:bool1?"	#9ACD32":"",borderRight: 'none' }}>{item.options.a}</label>
                                                        <span className="input-group-text" style={{ backgroundColor:bool1?"	#9ACD32":"#fff",borderLeft: 'none' }}>
                                                            <div className="form-check" >
                                                                <input className="form-check-input" onClick={() => {
                                                                setbool1(true)
                                                                setbool2(false)
                                                                setbool3(false)
                                                                setbool4(false)
                                                            }} type="radio" checked={bool1}  value="" />
                                                            </div>
                                                        </span>
                                                    </div>

                                                </div>

                                                <div className="col-sm-4">

                                                    <div className="input-group mb-3">
                                                        <label className="form-control" style={{backgroundColor:bool2?"	#9ACD32":"", borderRight: 'none' }}>{item.options.b}</label>
                                                        <span className="input-group-text" id="basic-addon1" style={{ backgroundColor:bool2?"#9ACD32":"#fff", borderLeft: 'none' }}>
                                                            <div className="form-check" >
                                                                <input className="form-check-input" onClick={() => {
                                                                


                                                                setbool1(false)
                                                                setbool2(true)
                                                                setbool3(false)
                                                                setbool4(false)
                                                            }} type="radio" checked={bool2} value="" id="flexCheckDefault" />
                                                            </div>
                                                        </span>
                                                    </div>



                                                </div>
                                            </div>
                                        </div>


                                        <div className="col-sm-12" style={{ padding: '0rem 3rem' }}>
                                            <div className="row">
                                                <div className="col-sm-4">


                                                    <div className="input-group mb-3" >
                                                        <label className="form-control" style={{backgroundColor:bool3?"	#9ACD32":"", borderRight: 'none' }}>{item.options.c}</label>
                                                        <span className="input-group-text" id="basic-addon1" style={{backgroundColor:bool3?"#9ACD32":"#fff", borderLeft: 'none' }}>
                                                            <div className="form-check" >
                                                                <input className="form-check-input" onClick={() => {
                                                                setbool1(false)
                                                                setbool2(false)
                                                                setbool3(true)
                                                                setbool4(false)
                                                            }} type="radio" checked={bool3} value="" id="flexCheckDefault" />
                                                            </div>
                                                        </span>
                                                    </div>


                                                </div>
                                                <div className="col-sm-4">


                                                    <div className="input-group mb-3">
                                                        <label className="form-control" aria-describedby="basic-addon1" style={{backgroundColor:bool4?"	#9ACD32":"", borderRight: 'none' }}>{item.options.d}</label>
                                                        <span className="input-group-text" id="basic-addon1" style={{backgroundColor:bool4?"#9ACD32":"#fff", borderLeft: 'none' }}>
                                                            <div className="form-check"  >
                                                                <input className="form-check-input" onClick={() => {
                                                                setbool1(false)
                                                                setbool2(false)
                                                                setbool3(false)
                                                                setbool4(true)
                                                            }} type="radio" checked={bool4} value="" id="flexCheckDefault" />
                                                            </div>
                                                        </span>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                    </>
                                )
                            }
                        })
                    }



                </div>
            </div>



            <div className='mt-5' style={{ textAlign: 'center' }}>

                <span className='mx-3' disabled={num === Question.length - 1} style={{ width: '50%', fontSize: '.9rem' }} onClick={() => {
                    Skiparr[count] = num;
                    console.log(Skiparr);
                    setcount(count + 1);
                    setnum(num + 1);
                    setbool1(false) 
                    setbool2(false)
                    setbool3(false)
                    setbool4(false)

                }}>Skip</span>

            </div>


            <div className='mt-3' style={{ textAlign: 'center' }}>

                <button className='btn mx-3' style={{ width: '50%', borderRadius: '15px', fontSize: '.9rem', boxShadow: 'none',backgroundColor:bool1 || bool2 || bool3 || bool4? '#000080':'',color:bool1 || bool2 || bool3 || bool4 ?'#fff':''}} onClick={() => {
                    if (num === Question.length - 1) {
                    } else {
                        setnum(num + 1);
                    }

                    setbool1(false) 
                    setbool2(false)
                    setbool3(false)
                    setbool4(false)

                }}>{num === Question.length - 1 ? "Submit" : 'Next'} </button>


            </div>





        </div>
    )
}

export default QuesOnMobile


