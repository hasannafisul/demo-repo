import React, { useState, useRef, useEffect } from 'react';

import logo1 from '../Images/logo1.webp'
import { Num, Question } from './Number'
import useMediaQuery from 'use-mediaquery';
import "../App.css";
const Header = () => {




    const matches1 = useMediaQuery(`(min-width:820px)`)
    const matches2 = useMediaQuery(`(min-width:1030px)`)
    const matches3 = useMediaQuery(`(min-width:576px)`)
    const Ref = useRef(null);
    const [timer, setTimer] = useState('00:00:00');
    const [num, setnum] = useState(0);
    const [qnum, setqnum] = useState(0)
    let Skiparr = [];


    const [count, setcount] = useState(0)




    const getTimeRemaining = (e) => {
        const total = Date.parse(e) - Date.parse(new Date());
        const seconds = Math.floor((total / 1000) % 60);
        const minutes = Math.floor((total / 1000 / 60) % 60);
        const hours = Math.floor((total / 1000 / 60 / 60) % 24);
        return {
            total, hours, minutes, seconds
        };
    }


    const startTimer = (e) => {
        let { total, hours, minutes, seconds } = getTimeRemaining(e);
        if (total >= 0) {


            setTimer(
                (hours > 9 ? hours : '0' + hours) + ':' +
                (minutes > 9 ? minutes : '0' + minutes) + ':'
                + (seconds > 9 ? seconds : '0' + seconds)
            )
        }
    }


    const clearTimer = (e) => {


        setTimer('00:00:00');


        if (Ref.current) clearInterval(Ref.current);
        const id = setInterval(() => {
            startTimer(e);
        }, 1000)
        Ref.current = id;
    }

    const getDeadTime = () => {
        let deadline = new Date();


        deadline.setSeconds(deadline.getSeconds() + 1200);
        return deadline;
    }


    useEffect(() => {
        clearTimer(getDeadTime());
    }, []);
    return (
        <div className='container-fluid'>

            <header className='mt-4' >
                <div className="col-sm-12" >
                    <div className="row">
                        <div className="col-sm-1"></div>
                        <div className="col-sm-3" style={{ display: 'flex', justifyContent: 'start', alignItems: 'center' }}>
                            <img src={logo1} alt="" />
                            <h4> Online Exam </h4>
                        </div>
                        <div className="col-sm-5"></div>
                        <div className="col-sm-2" style={{ display: 'flex', justifyContent: 'start', alignItems: 'center' }} >
                            <h4 style={{ color: 'green' }}>Welcome Nafis</h4>
                        </div>


                    </div>

                </div>

            </header>


            <div className='mt-4'>
                <div className="col-sm-12">
                    <div className="row">
                        <div className="col-sm-1"></div>
                        <div className={matches1 ? "col-sm-3" : "col-sm-12"}>
                            <p style={{ textAlign: matches1 ? "" : 'center' }}>General Aptitude Test</p>

                            <span style={{ float: 'left', marginLeft: '25px', display: !matches1 ? 'block' : 'none' }}>Attempted : 15</span>
                            <p style={{ float: 'right', marginRight: '25px', display: !matches1 ? 'block' : 'none' }}>skip : 5</p>


                        </div>
                        <div className="col-sm-12" style={{ display: !matches1 ? 'block' : 'none' }}>

                            <p style={{ float: 'left', marginLeft: '25px', display: !matches1 ? 'block' : 'none' }}>Total 20/20</p>
                            <p style={{ float: 'right', marginRight: '25px', display: !matches1 ? 'block' : 'none' }}>Time Left:{timer}</p>

                        </div>
                        <div className="col-sm-2" style={{ display: matches1 ? 'block' : 'none' }} >
                            <p>Attempted : 15</p>
                        </div>
                        <div className="col-sm-2" style={{ display: matches1 ? 'block' : 'none' }}>
                            <p>skip : 5</p>
                        </div>
                        <div className="col-sm-2" style={{ display: matches1 ? 'block' : 'none' }}>
                            <p>Total 20/20</p>
                        </div>
                        <div className="col-sm-2" style={{ display: matches1 ? 'block' : 'none' }}>

                            <p>Time Left:{timer}</p>
                            {/* <button onClick={onClickReset}>Reset</button> */}

                        </div>


                    </div>

                </div>
            </div>

            <div>
                <div className="col-sm-12" style={{ padding: '0px 20px' }}>
                    <div className="row">
                        <div className="col-sm-1"></div>

                        <div className="col-sm-2 mt-5" style={{ border: '2px solid Black', maxHeight: '300px', overflowY: !matches2 && matches3 ? "scroll" : "hidden" }}>
                            {Question.map((item, index) => {
                                // console.log(Skiparr.includes(index));
                                return (<button key={index} className="mx-1 my-1" style={{ backgroundColor: Skiparr.includes(index) ? '#3bc43b' : 'none' }} onClick={() => setnum(index)}> {index + 1}</button>);
                            })}

                        </div>
                        <div className="col-sm-2"></div>
                        <div className="col-sm-6 mt-5">
                            <div className="row">
                                {
                                    Question.map((item, index) => {

                                        if (num === index) {

                                            return (
                                                <>
                                                    <div className="col-sm-12">
                                                        <p>{item.question}</p>
                                                    </div>
                                                    <div className="col-sm-12">
                                                        <div className="row">
                                                            <div className="col-sm-3">
                                                                <div className="form-check form-check-inline">
                                                                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                                                    <label className="form-check-label" for="inlineRadio1">  {item.options.a}</label>
                                                                </div>
                                                            </div>
                                                            <div className="col-sm-3">

                                                                <div className="form-check form-check-inline">
                                                                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                                                    <label className="form-check-label" for="inlineRadio1"> {item.options.b}</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div className="col-sm-12">
                                                        <div className="row">
                                                            <div className="col-sm-3">
                                                                <div className="form-check form-check-inline">
                                                                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                                                                    <label className="form-check-label" for="inlineRadio1"> {item.options.c}</label>
                                                                </div>
                                                            </div>

                                                            <div className="col-sm-3">

                                                                <div className="form-check form-check-inline">
                                                                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option" />
                                                                    <label className="form-check-label" for="inlineRadio1">  {item.options.d}</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   
                                                </>
                                            )
                                        }
                                    })
                                }
                                 <div className='col-sm-10 mt-3' style={{ display: 'flex', justifyContent: 'start', alignItems: 'start' }}>

<button className='btn btn-warning' disabled={num === 0 ? true : false} style={{ padding: '1px 8px', fontSize: '16px' }} onClick={() => {
    setnum(num - 1);
}}>Prev</button>
<button className='btn btn-primary mx-3' disabled={num === Question.length - 1} style={{ padding: '1px 8px', fontSize: '16px' }} onClick={() => {
    //    setqnum(item.number)
    Skiparr[count] = num;
    console.log(Skiparr);
    setcount(count + 1);
    setnum(num + 1);
    // console.warn(count);
}}>Skip</button>

<button className='btn btn-success mx-3' style={{ padding: '1px 8px', fontSize: '16px' }} onClick={() => {
    if (num === Question.length - 1) {
        // document.write("Submit Successfully")
    } else {
        setnum(num + 1);
    }
}}>{num === Question.length - 1 ? "Submit" : 'Next'} </button>


</div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    )
}

export default Header
















