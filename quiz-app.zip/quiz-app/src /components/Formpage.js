
import axios from 'axios';
import React, { useState } from 'react';

const Signup = () => {
  const [name, setname] = useState("");
  const [phone, setphone] = useState("")
  const [email, setemail] = useState("")
  const [password, setpassword] = useState("")
  const [confirmpassword, setconfirmpassword] = useState("")
  const [image, setimage] = useState("")
  const [imagename, setimagename] = useState("");
 




  const PostData = async (e) => {
    e.preventDefault(); 

    if (password === confirmpassword) {

      
      // fetch("http://localhost:1998/register", {
      //   method: 'POST',
      //   headers: {
      //     "Content-Type": "application/json"
      //   },
      //   body: JSON.stringify({

      //     name, email, phone, password, confirmpassword,imagename
      //   })
        
      // })
      axios.post("http://localhost:1998/register",{name, email, phone, password, confirmpassword,imagename}).then((res)=>{
        // console.log(res);
        // if (res.data.status == 422 || !res.data) {
          // } else {
            setname('')
            setphone('')
            setemail('')
            setpassword("")
            setconfirmpassword('')
            setimagename('')
           

           window.alert(res.data.msg)
          //  window.alert(res.data.mesg)

          //  console.log(res);
            console.log("Successfull Registration");
            
            // }
          }).catch((err)=>{
            console.log("Invalid Registration");
            console.log(err);
          })
          // const data = await resp.json();
          // console.log(data);
          
          
        } else {
          document.write("password are not matched")
        }

        
        
      }




  const handleApi=()=>{

    const url = 'http://localhost:1998/api/image'
    const formData = new FormData()
    formData.append('image',image)
    axios.post(url, formData).then((res)=>{
console.log(res.data);


    }).catch((err)=>{
        console.log(err);
    })
 

}


const handlechange=(e)=>{
console.log(typeof(e.target.files[0].name))
setimage(e.target.files[0])
setimagename(e.target.files[0].name);
}



  return (
    <div className='container-fluid' style={{ backgroundColor: '#E1F8DC' }}>
      <div className="row">
        <div className="col-sm-3"></div>
        <div className="col-sm-4 mt-5" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <form >


            <label for="input text" className="form-label">Name</label>
            <input type="text" value={name} className="form-control" placeholder="name" aria-label="name"
              onChange={(e) => {
                setname(e.target.value);
              }} />

            <label for="input tel" className="form-label">phone Number</label>
            <input type="Number" value={phone} className="form-control" placeholder="phone number" aria-label="phonenumber"
              onChange={(e) => {
                setphone(e.target.value);
              }} />


            <label for="inputEmail4" className="form-label">Email</label>
            <input type="email" value={email} className="form-control" placeholder='enter the email' id="inputEmail4" aria-label="email" onChange={(e) => {
              setemail(e.target.value);
            }} />

            <label for="inputPassword4" className="form-label">Password</label>
            <input type="password" value={password} className="form-control" placeholder='enter the password' id="inputPassword4" aria-label="password" onChange={(e) => {
              setpassword(e.target.value);
            }} />


            <label for="inputConfirmPassword4" className="form-label">Confirm Password </label>
            <input type="password" value={confirmpassword} className="form-control" placeholder='confirm password' id="inputPassword4" aria-label="confirmpassword" onChange={(e) => {
              setconfirmpassword(e.target.value)
            }} />


           <label for="file" className="form-label">Upload file</label>
            <input type="file"  className="form-control"  id="file" aria-label="file" onChange={handlechange} />




            <button type="submit" className="btn btn-primary mb-5 mt-3"
              onClick={(e) =>{PostData(e);
              handleApi()
              }}>Sign up</button>



          </form>



        </div>
      </div>
    </div>

  )
}

export default Signup

