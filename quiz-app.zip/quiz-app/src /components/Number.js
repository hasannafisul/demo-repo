export const Num =[
    '01','02','03','04',
    '05','06','07','08',
    '09','10','11','12',
    '13','14','15','16',
    '17', '18', '19','20'

]

export const Question=[
    {
        number:1,
       question: "1.Who is the discovered of India ?",
       options:{
           "a":"Abraham Lincoln",
           "b":"George Washington",
           "c":"L. Martin",
           "d":"vasco da gama"
       },
       answer: "d"
    },
    {
        number:2,
        question: "2.Which state has signed MoU with Telangana to set up all women-run cooperative bank ?",
        options:{
            "a":"Andhra Pradesh",
            "b":"Rajasthan",
            "c":"Karnataka",
            "d":"Punjab"
        },
        answer: "b"
     },
    

{
    number:3,
    question:"3.Which animal features in the 36th National Games 2022, to be held in Gujarat ?",
options:{
'a': 'Rhino',
'b': 'Lion',
'c': 'Tiger',
'd': 'Elephant'
},
answer: "b"
},


{
    number:4,
    question:"4.Which is the headquarters of the ‘United Nations Relief and Works Agency for Palestine Refugees in the Near East (UNRWA)’ ?",
options:
{
    'a': 'Geneva',
'b': 'Paris',
'c': "Amman and Gaza",
'd': 'Jerusalem'
},
answer : 'c'

},



{
    number:5,
   question: "5.Which Indian economist has been appointed the chief economist of World Bank?",
options:{
"a": 'Raghuram Rajan',
'b': "Urjit Patel",
'c': 'Indermit Gill',
'd': 'Viral Acharya'
},
answer : 'c'
},


{
    number:6,
    question: "6.Pallikaranai Marsh Reserve Forest and Pichavaram Mangrove, which were designated as ‘Ramsar sites’ are located in which state?",
options:{
    'a': 'Tamil Nadu',
'b': 'Rajasthan',
'c': 'Kerala',
'd': 'Telangana'
},
answer : 'a'
},



{
    number:7,
    question: "7.Which is the venue of the 11th World Urban Forum held in 2022?",
    options :{
'a': 'Spain',
'b': 'Poland',
'c': 'Australia',
'd': 'France'
    },
answer:'b'    
},

{
    number:8,
question:"8.‘Sambhajinagar’ is the new name of which Indian city?",
options:{
'a': 'Ahmadabad',
'b': 'Aurangabad',
'c' :'Firozabad',
'd' :'Ghaziabad'

},
answer:'b'
},

{
    number:9,
question:"9.Which bloc has agreed to create an open International Climate Club?",
options:{
    'a': 'BIMSTEC',
'b': 'G-7',
'c': 'European Union',
'd': 'G-20'
},
answer:'b'
},

{
    number:10,
question:"10.Which NATO member was in the news for agreeing to support Sweden and Finland’s membership of NATO alliance?",
options:{
    'a': 'Turkey',
'b': 'Canada',
'c': 'Greece',
'd': 'France'
},
answer:'a'
},

{
    number:11,
question:"11.Which tennis player became the first player in history to win 80 matches in all four Grand Slams?",
options:{
    'a': 'Rafael Nadal',
'b': 'Novak Djokovic',
'c': 'Roger Federer',
'd': 'Andy Murray'

},
answer:'b'
},

{
    number:12,
question:"12.Which is the only Indian city to achieve the ‘Gold’ standard category in Asia Pacific Sustainability Index 2021?",
options:{
    'a': 'New Delhi',
'b': 'Bengaluru',
'c': 'Hyderabad',
'd': 'Mumbai',
},
answer:'b'
},

{
    number:13,
    question:"13.Which is the only institution in India to issue ‘Electoral bonds’?",
options:{
    'a': 'RBI',
'b': 'SBI',
'c': 'NITI Aayog',
'd': 'CBDT'
},
answer:'b'
},

{
    number:14,
    question:"14.Which institution along with World Food Programme (WFP) launched a report titled ‘Take Home Ration-Good Practices across the State/UTs’?",
options:{
    'a': 'NABARD',
'b': 'Ministry of Consumer Affairs and Food Distribution',
'c': 'NITI Aayog',
'd': 'Pratham Foundation'
},
answer:'a'
},

{
    number:15,
    question:"15.As per the UN World Drug Report, which country has the most number: of opiate users in the world?",
options:{
    'a': 'Afghanistan',
'b': 'India',
'c': 'Pakistan',
'd': 'China'
},
answer:'b'
},

{
    number:16,
    question:"16.Which Union Ministry released the ‘Foreign Contribution (Regulation) Amendment Rules, 2022’?",
options:{
    'a': 'Ministry of External Affairs',
'b': 'Ministry of Home Affairs',
'c': 'Ministry of Finance',
'd': 'Ministry of Commerce and Industry'
},
answer:'b'
},


{
    number:17,
    question:"17.Dr. Rajendra Prasad Memorial Award, which was recently announced, is associated with which filed?",
options:{
'a': 'Teaching',
'b': 'Public Administration',
'c': 'Social Service',
'd': 'Entrepreneurship'
},
answer:'b'
},

{
    number:18,
    question:"18.What is ‘ARYABHAT-1’ which was seen in the news recently?",
options:{
'a': 'Ballistic Missile',
'b': 'Earth Observation Satellite',
'c':'Prototype of Analog chipset',
'd':'Super Computer'
},
answer:'c'
},

{
    number:19,
    question:"19.The 30 NATO allies recently signed the accession protocols for which countries?",
options:{
'a':'Turkey and Malta',
'b':'Sweden and Finland',
'c':'Norway and Sweden',
'd':'Norway and Turkey'
},
answer:'b'
},

{
    number:20,
    question:"20.Which city is the host of ‘2022 Global biodiversity conclave’?",
options:{
'a':'Paris',
'b':'Bonn',
'c':'Geneva',
'd':'Davos'
},
answer:'b'
}
]