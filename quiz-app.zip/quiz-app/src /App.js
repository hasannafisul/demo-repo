// import React from 'react'
// import Mapping from './components/Mapping'


// const App = () => {
//   return (
//     <div>
//       <Header/>
// {/* <Mapping/> */}

//     </div>
//   )
// }

// export default App





// 2nd react components


import React, { useState } from 'react'


import {
  BrowserRouter as Router,
  Routes,
  Route

}
  from 'react-router-dom';



import Ncontext from './ContextC'

import OnlineSignup from './components/OnlineSignup'
// import Captcha from './components/Captcha'
import QuizPage1 from './components/QuizPage1'
import Attempted from './components/Attempted';
import ButtonMobile from './components/ButtonMobile';
import BackonQuest from './components/BackonQuest';



const App = () => {
  const savedSession= localStorage.getItem('session');
const [sessionId, setsessionId] = useState(savedSession || 0)
const [min, setmin] = useState(30);
const [sec, setsec] = useState(0);
const [boolcheck, setboolcheck] = useState(false);
const [bool7, setbool7] = useState(false);
const [bool8, setbool8] = useState(false);
const [bool9, setbool9] = useState(false);
const [bool10, setbool10] = useState(true);
const [bool11, setbool11] = useState(false);
document. addEventListener("contextmenu", function (e){ e. preventDefault(); }, false);
document.onkeydown = function (e) {
  // disable :F12 key
  //   if (e.key == 'F12') {
  //     return false;
  //   }
  // // disable :I key
  //   if (e.ctrlKey ) {
  //     return false;
  //   }
  //   // disable J key
  //   if (e.ctrlKey && e.shiftKey && e.key == 'J') {
  //     return false;
  //   }
  //   // disable U key
  //   if (e.ctrlKey && e.key == 'U') {
  //     return false;
  //   }
    // if (e.shiftKey) {
    //   return false;
    // }
}
  return (
    <>


<Ncontext.Provider value={{sessionId,setsessionId,min,setmin,sec,setsec,boolcheck, setboolcheck,bool7, setbool7,bool8, setbool8,bool9, setbool9,bool10, setbool10,bool11, setbool11}} >
{/* <Header/> */}

{/* <HomePage/> */}

{/* <MobonQues/> */}
{/* <GetSolution/> */}

{/* <HeaderOrg/> */}

{/* <DemoPage/> */}


{/* <DesktopInstruct/> */}
{/* <QuesOnMobile/> */}


{/* <ProgressBar/> */}

{/* <Signup/> */}

{/* <QuizPage/> */}





{/* <Captcha/> */}

<Router>



        {/* <Navbar /> */}

        <Routes>

     <Route exact path="/" element={<OnlineSignup/>}> </Route>


          {/* <Route exact path="/signup" element={<Signup />}> </Route>


          <Route path="/login" element={<LoginForm />}> </Route>

          <Route path="/forget" element={<ForgetPass />}> </Route>


          <Route path="/dash" element={<WelcomePage />}> </Route> */}
            {/* <Route path="/instruct" element={<InstructOnMob />} > </Route> */}

            <Route path='/btnonmob' element={<ButtonMobile/> }></Route>
            <Route path="/quiz" element={<QuizPage1/>} > </Route>



        </Routes>

      </Router>

      {/* <AdminPage/> */}


      </Ncontext.Provider>
    </>
  )
}

export default App




