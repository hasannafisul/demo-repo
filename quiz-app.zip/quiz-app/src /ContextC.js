import {createContext} from "react";
const Ncontext = createContext();
export default Ncontext;